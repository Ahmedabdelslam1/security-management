// شاشة الدخول بتصميم أزرق/ذهبي متوافق مع الواجهة الرئيسية
import 'package:flutter/material.dart';
import '../api.dart';
import '../state.dart';
import 'shell.dart';

const _blue = Color(0xFF123F91);
const _blue2 = Color(0xFF2459B5);
const _yellow = Color(0xFFF7C52B);

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _u = TextEditingController();
  final _p = TextEditingController();
  final _rgName = TextEditingController();
  final _rgUser = TextEditingController();
  final _rgPass = TextEditingController();
  String _msg = '';
  bool _err = false;
  bool _busy = false;
  bool _reg = false;

  @override
  void initState() { super.initState(); Api.getUrl(); }

  void _say(String m, [bool e = false]) => setState(() { _msg = m; _err = e; });

  Future<void> _login() async {
    setState(() => _busy = true);
    try {
      await Api.getUrl();
      final r = await Api.call('login', [_u.text.trim().toLowerCase(), _p.text]);
      await Api.saveToken((r as Map)['token'] as String);
      await App.I.bootstrap();
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const Shell()));
    } on SessionExpired { _say('انتهت الجلسة، حاول مرة أخرى', true); }
    on ApiException catch (e) { _say(e.message, true); }
    catch (e) { _say('خطأ غير متوقع: $e', true); }
    finally { if (mounted) setState(() => _busy = false); }
  }

  Future<void> _register() async {
    setState(() => _busy = true);
    try {
      await Api.getUrl();
      await Api.call('register', [_rgName.text.trim(), _rgUser.text.trim().toLowerCase(), _rgPass.text]);
      _say('تم إرسال الطلب — بانتظار موافقة الإدارة');
      setState(() => _reg = false);
    } on ApiException catch (e) { _say(e.message, true); }
    catch (e) { _say('خطأ غير متوقع: $e', true); }
    finally { if (mounted) setState(() => _busy = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [_blue, _blue2])),
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(22),
                child: Column(
                  children: [
                    Container(
                      width: 108, height: 108,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(30), boxShadow: const [BoxShadow(color: Color(0x44000000), blurRadius: 18, offset: Offset(0, 8))]),
                      child: Image.asset('assets/logo.png', fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.security_rounded, color: _blue, size: 62)),
                    ),
                    const SizedBox(height: 18),
                    const Text('إدارة الأمن', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 4),
                    const Text('نظام متكامل لإدارة الأمن والحضور والبوابات', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, fontSize: 13.5, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 25),
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28), boxShadow: const [BoxShadow(color: Color(0x44000000), blurRadius: 20, offset: Offset(0, 10))]),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(_reg ? 'إنشاء حساب' : 'تسجيل الدخول', textAlign: TextAlign.center, style: const TextStyle(color: _blue, fontSize: 21, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 17),
                          if (!_reg) ...[
                            _field(_u, 'اسم المستخدم', Icons.person_outline_rounded),
                            const SizedBox(height: 12),
                            _field(_p, 'كلمة المرور', Icons.lock_outline_rounded, obscure: true, onSubmitted: (_) => _login()),
                          ] else ...[
                            _field(_rgName, 'الاسم بالكامل', Icons.badge_outlined),
                            const SizedBox(height: 12),
                            _field(_rgUser, 'اسم المستخدم', Icons.person_outline_rounded),
                            const SizedBox(height: 12),
                            _field(_rgPass, 'كلمة المرور', Icons.lock_outline_rounded, obscure: true),
                          ],
                          const SizedBox(height: 17),
                          if (_busy) const Center(child: CircularProgressIndicator(color: _blue)) else SizedBox(
                            height: 52,
                            child: FilledButton(
                              onPressed: _reg ? _register : _login,
                              style: FilledButton.styleFrom(backgroundColor: _blue, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                              child: Text(_reg ? 'إرسال طلب التسجيل' : 'دخول', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                            ),
                          ),
                          TextButton(onPressed: () => setState(() { _reg = !_reg; _msg = ''; }), child: Text(_reg ? 'لديك حساب؟ سجّل الدخول' : 'مستخدم جديد', style: const TextStyle(color: _blue, fontWeight: FontWeight.w800))),
                          if (_msg.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(_msg, textAlign: TextAlign.center, style: TextStyle(color: _err ? Colors.red.shade700 : Colors.green.shade700, fontSize: 13, fontWeight: FontWeight.w700))),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text('Security Management', style: TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String label, IconData icon, {bool obscure = false, ValueChanged<String>? onSubmitted}) {
    return TextField(
      controller: c,
      obscureText: obscure,
      onSubmitted: onSubmitted,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: _blue),
        filled: true,
        fillColor: const Color(0xFFF3F6FA),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: Color(0xFFE0E6EF))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: _blue, width: 1.5)),
      ),
    );
  }
}
