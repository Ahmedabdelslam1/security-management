// الهيكل الرئيسي للتطبيق — تصميم خدمات حديث قريب من الواجهة المرجعية
import 'dart:async';
import 'package:flutter/material.dart';
import '../state.dart';
import 'attendance.dart';
import 'workers.dart';
import 'settlement.dart';
import 'reports.dart';
import 'gate.dart';
import 'users.dart';
import 'monitor.dart';
import 'settings.dart';

const _blue = Color(0xFF123F91);
const _blue2 = Color(0xFF2459B5);
const _yellow = Color(0xFFF7C52B);
const _bg = Color(0xFFF4F7FB);

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  String _tab = 'home';
  int _bottom = 0;
  Timer? _timer;
  DateTime _now = DateTime.now();

  @override
  void initState() {
    super.initState();
    App.I.bootstrap(silent: true).catchError((_) {});
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final app = App.I;
    final u = app.user;
    if (u == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: _bg,
        body: SafeArea(
          bottom: false,
          child: Column(
            children: [
              _Header(user: u, now: _now, onMenu: _openMore),
              Expanded(child: _body(_tab, u)),
            ],
          ),
        ),
        bottomNavigationBar: _BottomBar(
          index: _bottom,
          onChanged: (i) => _onBottom(i, u),
        ),
      ),
    );
  }

  void _onBottom(int i, dynamic u) {
    setState(() {
      _bottom = i;
      switch (i) {
        case 0:
          _tab = 'home';
          break;
        case 1:
          _tab = u.can('attendance') ? 'attendance' : 'reports';
          break;
        case 2:
          _tab = u.can('workers') ? 'workers' : 'gate';
          break;
        case 3:
          _tab = u.can('reports') ? 'reports' : (u.isAdmin ? 'monitor' : 'home');
          break;
        case 4:
          _tab = 'settings';
          break;
      }
    });
  }

  Widget _body(String tab, dynamic u) {
    if (tab == 'home') return _ServicesHome(onOpen: _openTab);
    switch (tab) {
      case 'attendance': return const AttendanceScreen();
      case 'workers': return const WorkersScreen();
      case 'settlement': return const SettlementScreen();
      case 'reports': return const ReportsScreen();
      case 'gate': return const GateScreen();
      case 'users': return const UsersScreen();
      case 'monitor': return const MonitorScreen();
      case 'settings': return const SettingsScreen();
      default: return _ServicesHome(onOpen: _openTab);
    }
  }

  void _openTab(String id) {
    setState(() {
      _tab = id;
      _bottom = id == 'home' ? 0 : 3;
    });
  }

  void _openMore() {
    final u = App.I.user;
    if (u == null) return;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: 46, height: 5, decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(10))),
              const SizedBox(height: 14),
              ListTile(leading: const Icon(Icons.settings_outlined, color: _blue), title: const Text('الإعدادات'), onTap: () { Navigator.pop(context); _openTab('settings'); }),
              if (u.isAdmin) ListTile(leading: const Icon(Icons.manage_accounts_outlined, color: _blue), title: const Text('المستخدمون والصلاحيات'), onTap: () { Navigator.pop(context); _openTab('users'); }),
              ListTile(leading: const Icon(Icons.logout, color: Colors.red), title: const Text('تسجيل الخروج', style: TextStyle(color: Colors.red)), onTap: () { Navigator.pop(context); _logout(); }),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _logout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تأكيد الخروج'),
        content: const Text('هل تريد تسجيل الخروج من التطبيق؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(style: FilledButton.styleFrom(backgroundColor: _blue), onPressed: () => Navigator.pop(context, true), child: const Text('خروج')),
        ],
      ),
    );
    if (ok != true) return;
    await App.I.logout();
    if (!mounted) return;
    Navigator.of(context).pushNamedAndRemoveUntil('/', (_) => false);
  }
}

class _Header extends StatelessWidget {
  final dynamic user;
  final DateTime now;
  final VoidCallback onMenu;
  const _Header({required this.user, required this.now, required this.onMenu});

  @override
  Widget build(BuildContext context) {
    final count = App.I.workers.length;
    return Container(
      height: 114,
      decoration: const BoxDecoration(
        gradient: LinearGradient(begin: Alignment.centerRight, end: Alignment.centerLeft, colors: [_blue, _blue2]),
        boxShadow: [BoxShadow(color: Color(0x33000000), blurRadius: 12, offset: Offset(0, 5))],
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 10),
        child: Row(
          children: [
            _HeaderButton(icon: Icons.search_rounded, onTap: () {}),
            const SizedBox(width: 9),
            Expanded(
              child: Container(
                height: 74,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(color: Colors.white.withOpacity(.10), borderRadius: BorderRadius.circular(18)),
                child: Row(
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
                      padding: const EdgeInsets.all(7),
                      child: Image.asset('assets/logo.png', fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.shield_rounded, color: _blue, size: 30)),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(user.name.toString(), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700)),
                          const SizedBox(height: 2),
                          Text('إدارة الأمن  •  $count عامل', style: const TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w600)),
                          Text(_clock(now), style: const TextStyle(color: _yellow, fontSize: 15, fontWeight: FontWeight.w900)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 9),
            _HeaderButton(icon: Icons.menu_rounded, onTap: onMenu),
          ],
        ),
      ),
    );
  }

  static String _clock(DateTime d) {
    int h = d.hour % 12; if (h == 0) h = 12;
    final ap = d.hour < 12 ? 'ص' : 'م';
    return '$h:${d.minute.toString().padLeft(2, '0')} $ap';
  }
}

class _HeaderButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _HeaderButton({required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) => Material(
    color: Colors.white.withOpacity(.10),
    borderRadius: BorderRadius.circular(18),
    child: InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: SizedBox(width: 64, height: 64, child: Icon(icon, color: Colors.white, size: 34)),
    ),
  );
}

class _ServicesHome extends StatelessWidget {
  final void Function(String id) onOpen;
  const _ServicesHome({required this.onOpen});

  @override
  Widget build(BuildContext context) {
    final u = App.I.user!;
    final items = <_ServiceItem>[
      if (u.can('attendance')) _ServiceItem('attendance', 'الحضور', Icons.fact_check_rounded),
      if (u.can('workers')) _ServiceItem('workers', 'العاملين', Icons.groups_rounded),
      if (u.can('attendance')) _ServiceItem('settlement', 'التسوية', Icons.payments_rounded),
      if (u.can('reports')) _ServiceItem('reports', 'التقارير', Icons.bar_chart_rounded),
      if (u.can('gate')) _ServiceItem('gate', 'دفتر البوابة', Icons.local_shipping_rounded),
      if (u.isAdmin) _ServiceItem('monitor', 'المتابعة', Icons.notifications_active_rounded),
      if (u.isAdmin) _ServiceItem('users', 'المستخدمون', Icons.manage_accounts_rounded),
      _ServiceItem('settings', 'الإعدادات', Icons.settings_rounded),
    ];

    return CustomScrollView(
      physics: const BouncingScrollPhysics(),
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 10),
            child: Row(
              children: [
                const Expanded(child: Text('الخدمات', style: TextStyle(color: Color(0xFF173E80), fontSize: 22, fontWeight: FontWeight.w900))),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                  decoration: BoxDecoration(color: _yellow.withOpacity(.18), borderRadius: BorderRadius.circular(20)),
                  child: Text('${items.length} خدمة', style: const TextStyle(color: Color(0xFF8A6500), fontWeight: FontWeight.w800, fontSize: 12)),
                ),
              ],
            ),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(18, 4, 18, 22),
          sliver: SliverGrid(
            delegate: SliverChildBuilderDelegate((context, i) => _ServiceCard(item: items[i], onTap: () => onOpen(items[i].id)), childCount: items.length),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 14, mainAxisSpacing: 14, childAspectRatio: 1.27),
          ),
        ),
      ],
    );
  }
}

class _ServiceItem {
  final String id;
  final String title;
  final IconData icon;
  const _ServiceItem(this.id, this.title, this.icon);
}

class _ServiceCard extends StatelessWidget {
  final _ServiceItem item;
  final VoidCallback onTap;
  const _ServiceCard({required this.item, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(26),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(26),
        child: Ink(
          decoration: BoxDecoration(
            gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [_blue, _blue2]),
            borderRadius: BorderRadius.circular(26),
            border: const Border(bottom: BorderSide(color: _yellow, width: 6)),
            boxShadow: const [BoxShadow(color: Color(0x28000000), blurRadius: 12, offset: Offset(0, 5))],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(item.icon, color: _yellow, size: 48),
              const SizedBox(height: 12),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 7),
                child: Text(item.title, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BottomBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;
  const _BottomBar({required this.index, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    const items = [
      (Icons.apps_rounded, 'الخدمات'),
      (Icons.fact_check_rounded, 'الحضور'),
      (Icons.groups_rounded, 'العاملين'),
      (Icons.bar_chart_rounded, 'التقارير'),
      (Icons.settings_rounded, 'الإعدادات'),
    ];
    return Container(
      decoration: const BoxDecoration(color: Color(0xF01B4B98), borderRadius: BorderRadius.vertical(top: Radius.circular(25)), boxShadow: [BoxShadow(color: Color(0x35000000), blurRadius: 14, offset: Offset(0, -4))]),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 7, 8, 7),
          child: Row(
            children: List.generate(items.length, (i) {
              final selected = index == i;
              return Expanded(
                child: GestureDetector(
                  onTap: () => onChanged(i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    decoration: BoxDecoration(color: selected ? Colors.white.withOpacity(.20) : Colors.transparent, borderRadius: BorderRadius.circular(18)),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(items[i].$1, color: selected ? _yellow : Colors.white70, size: 26),
                        const SizedBox(height: 3),
                        Text(items[i].$2, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: selected ? Colors.white : Colors.white70, fontSize: 11.5, fontWeight: selected ? FontWeight.w900 : FontWeight.w700)),
                      ],
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}
