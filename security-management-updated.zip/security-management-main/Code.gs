/**
 * إدارة الأمن — الخلفية (Google Apps Script)
 * ------------------------------------------------------------
 * الإعداد:
 *  1) أنشئ Google Sheet جديدًا ثم: الإضافات/الامتدادات > Apps Script.
 *  2) الصق هذا الملف في Code.gs، وأنشئ ملف HTML باسم index والصق فيه ملف index.html.
 *  3) (اختياري) شغّل الدالة setup() مرة واحدة لمنح الصلاحيات وإنشاء الجداول.
 *  4) نشر > نشر كتطبيق ويب: التنفيذ بصفتي، الوصول: أي شخص. افتح الرابط.
 *  الدخول الأول:  admin / admin123  (غيّر كلمة المرور فورًا من زر 🔑)
 *  لو نسيت كلمة مرور المدير: شغّل resetAdminPassword() من المحرر.
 */

var TZ = 'Africa/Cairo';
var HALF_STATUS = 'حضور نصف يوم', HOURS_STATUS = 'حضور ساعات';
var STATUSES = ['حضور', HALF_STATUS, HOURS_STATUS, 'حضور + وقت اضافى', 'حضور + مبيت'];
var EXTRA_STATUSES = ['حضور + وقت اضافى', 'حضور + مبيت'];
var PERMS = ['workers', 'attendance', 'reports', 'gate', 'procs'];
var SESSION_TTL = 1800;             // الجلسة تنتهي بعد نصف ساعة بلا أي نشاط (تتجدد مع كل طلب)
var SESSION_MAX_IDLE = 30 * 60 * 1000;
var ONLINE_MS = 5 * 60 * 1000;      // متصل = نشاط خلال 5 دقائق
var MAX_LOG_ROWS = 5000;

var SHEETS = {
  Workers:    ['id', 'name', 'card', 'phone', 'wage', 'hours', 'lastSet', 'cardImg', 'photo', 'loc'],
  Attendance: ['date', 'wid', 'name', 'status', 'loc', 'wage', 'xh', 'notes', 'settleId', 'paidAmt'],
  Locations:  ['name'],
  Users:      ['username', 'name', 'salt', 'hash', 'status', 'role', 'perms', 'lastLogin', 'lastActive', 'platform', 'curPage', 'curPageAt'],
  Settlements:['id', 'date', 'from', 'to', 'wid', 'name', 'days', 'amount', 'user', 'createdAt', 'bonus', 'ded', 'tax', 'net', 'ot'],
  Gate:       ['id', 'seq', 'weekday', 'date', 'plate', 'time', 'driver', 'statement', 'notes', 'managers', 'host', 'images', 'createdBy', 'createdAt', 'action', 'rep', 'page', 'line', 'imgTypes', 'move'],
  Procs:      ['id', 'seq', 'date', 'weekday', 'plate', 'driver', 'rep', 'statement', 'ptype', 'docs', 'signed', 'signDate', 'signer', 'bookPage', 'supervisor', 'notes', 'other', 'createdBy', 'createdAt', 'page', 'line'],
  Log:        ['time', 'user', 'action', 'page', 'details', 'platform']
};
var SCHEMA_CHECKED_ = {};
var CUR_PLAT_ = ''; /* منصة الجلسة الحالية (web / android) تُضبط في auth_ وتُكتب في السجل */
function normPlat_(p) { p = String(p || '').toLowerCase(); return p === 'android' ? 'android' : (p === 'web' ? 'web' : ''); }

/* ===================== الصفحة ===================== */
// ===== تحديث تلقائي: الصفحة تُسحب مباشرة من GitHub (آخر نسخة) كل 5 دقائق =====
var REPO_RAW_INDEX = 'https://raw.githubusercontent.com/Ahmedabdelslam1/security-management/main/Index.html';

function doGet() {
  return HtmlService.createHtmlOutput(_liveIndex())
    .setTitle('إدارة الأمن')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

// يسحب آخر نسخة من الواجهة من GitHub مع تخزين مؤقت 5 دقائق — ولو GitHub وقع يرجع للنسخة المحلية
function _liveIndex() {
  var cache = CacheService.getScriptCache();
  try {
    var n = Number(cache.get('WEBX_N') || 0);
    if (n > 0) {
      var ks = []; for (var i = 0; i < n; i++) ks.push('WEBX_' + i);
      var m = cache.getAll(ks), html = '';
      for (var k = 0; k < n; k++) html += m[ks[k]] || '';
      if (html && /<html/i.test(html) && /<\/html>\s*$/i.test(html)) return html;
    }
  } catch (e0) {}
  try {
    var r = UrlFetchApp.fetch(REPO_RAW_INDEX + '?t=' + Date.now(), { muteHttpExceptions: true });
    if (r.getResponseCode() === 200) {
      var html2 = r.getContentText();
      if (/<html/i.test(html2) && html2.length > 10000) {
        try { // الحرف العربي = 2 بايت، لذا قطع صغيرة (حد المفتاح 100KB)، وفشل التخزين لا يمنع عرض النسخة الجديدة
          var CH = 30000, parts = Math.ceil(html2.length / CH), o = {};
          for (var j = 0; j < parts; j++) o['WEBX_' + j] = html2.slice(j * CH, (j + 1) * CH);
          o['WEBX_N'] = String(parts);
          cache.putAll(o, 300);
        } catch (e1) {}
        return html2;
      }
    }
  } catch (err) { /* نسقط للنسخة المحلية */ }
  return HtmlService.createHtmlOutputFromFile('index').getContent();
}

/* ===================== بوابة JSON لتطبيق الأندرويد (Flutter) =====================
 * الطلب:  POST {"action":"اسم_الدالة","args":[...]}   →   الرد: {"ok":true,"data":...} أو {"ok":false,"error":"..."}
 * فقط الدوال المسموح بها أدناه يمكن استدعاؤها (لا الدوال الداخلية ولا setup ولا resetAll).
 * ملاحظة: بعد أي تعديل لا بد من نشر نسخة جديدة (Deploy > Manage deployments > Edit > New version). */
function apiMap_() {
  return {
    login: login, logout: logout, register: register, changePassword: changePassword, ping: ping, presence: presence, appUrl: appUrl, rev: rev, addLog: addLog,
    bootstrap: bootstrap, saveDay: saveDay, settleWorkers: settleWorkers, listPayroll: listPayroll,
    updatePayrollAdj: updatePayrollAdj, saveWorker: saveWorker, deleteWorkers: deleteWorkers, getImage: getImage,
    setUser: setUser, addUser: addUser, resetUserPassword: resetUserPassword, deleteUser: deleteUser,
    getMonitor: getMonitor, listGate: listGate, saveGate: saveGate, deleteGate: deleteGate, getGateImage: getGateImage,
    listProcs: listProcs, saveProc: saveProc, deleteProc: deleteProc, getProcFiles: getProcFiles, refreshLive: refreshLive, srvVer: srvVer
  };
}

/* 4 = يدعم موقفي نصف يوم/ساعات + الحضور الحي (presence) */
function srvVer(token) { auth_(token); return '4'; }

/* تحديث يدوي من زر المستخدمين: يمسح الذاكرة المؤقتة ويسحب أحدث واجهة من GitHub ويرجع إصدار التطبيق المتاح */
function refreshLive(token) {
  auth_(token);
  var c = CacheService.getScriptCache(), ks = ['WEBX_N', 'GS_FN', 'GS_SN'];
  for (var i = 0; i < 30; i++) { ks.push('WEBX_' + i); ks.push('GS_F' + i); ks.push('GS_S' + i); }
  try { c.removeAll(ks); } catch (e) {}
  var html = _liveIndex();
  var ver = '';
  try {
    var r = UrlFetchApp.fetch('https://raw.githubusercontent.com/Ahmedabdelslam1/security-management/main/app-version.json?t=' + Date.now(), { muteHttpExceptions: true });
    if (r.getResponseCode() === 200) ver = String(JSON.parse(r.getContentText()).version || '');
  } catch (e2) {}
  return { web: html.length, appVersion: ver, at: now_() };
}

function doPost(e) {
  var out;
  try {
    var raw = (e && e.postData && e.postData.contents) || '{}';
    var req = JSON.parse(raw);
    var name = String(req.action || ''), map = apiMap_();
    if (!Object.prototype.hasOwnProperty.call(map, name)) throw new Error('إجراء غير معروف: ' + name);
    var args = Array.isArray(req.args) ? req.args : [];
    var data = map[name].apply(null, args);
    out = { ok: true, data: data === undefined ? null : data };
  } catch (err) {
    out = { ok: false, error: String((err && err.message) || err).replace(/^Error:\s*/, '') };
  }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}

function setup() {
  Object.keys(SHEETS).forEach(function (n) { sh_(n); });
  ensureAdmin_();
  return 'تم الإعداد: ' + ss_().getUrl();
}

function resetAdminPassword() {
  var salt = Utilities.getUuid();
  var users = readAll_('Users');
  var found = false;
  users.forEach(function (u) {
    if (u.username === 'admin') { u.salt = salt; u.hash = hash_(salt, 'admin123'); u.status = 'approved'; u.role = 'admin'; found = true; }
  });
  if (!found) { ensureAdmin_(); return; }
  writeAll_('Users', users);
}

/* ===================== أدوات الشيت ===================== */
var SSOBJ_ = null, SHOBJ_ = {};
function ss_() {
  if (SSOBJ_) return SSOBJ_;
  SSOBJ_ = ss0_();
  return SSOBJ_;
}
function ss0_() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty('SS_ID');
  if (id) return SpreadsheetApp.openById(id);
  var a = SpreadsheetApp.getActiveSpreadsheet();
  if (a) return a;
  var n = SpreadsheetApp.create('إدارة الأمن - البيانات');
  props.setProperty('SS_ID', n.getId());
  return n;
}

function sh_(name) {
  if (SHOBJ_[name]) return SHOBJ_[name];
  var sheet0 = sh0_(name);
  SHOBJ_[name] = sheet0;
  return sheet0;
}
function sh0_(name) {
  var s = ss_();
  var h = SHEETS[name];
  var sheet = s.getSheetByName(name);
  if (!sheet) {
    sheet = s.insertSheet(name);
    sheet.getRange(1, 1, sheet.getMaxRows(), h.length).setNumberFormat('@');
    sheet.getRange(1, 1, 1, h.length).setValues([h]).setFontWeight('bold');
    sheet.setFrozenRows(1);
    sheet.setRightToLeft(true);
    SCHEMA_CHECKED_[name] = 1;
  } else if (!SCHEMA_CHECKED_[name] && !CacheService.getScriptCache().get('SCH6_' + name)) {
    SCHEMA_CHECKED_[name] = 1;
    if (sheet.getMaxColumns() < h.length) sheet.insertColumnsAfter(sheet.getMaxColumns(), h.length - sheet.getMaxColumns());
    var cur = sheet.getRange(1, 1, 1, h.length).getValues()[0];
    var same = h.every(function (k, i) { return String(cur[i]) === k; });
    if (!same) {
      sheet.getRange(1, 1, sheet.getMaxRows(), h.length).setNumberFormat('@');
      sheet.getRange(1, 1, 1, h.length).setValues([h]).setFontWeight('bold');
    }
    try { CacheService.getScriptCache().put('SCH6_' + name, '1', 21600); } catch (e) {}
  }
  return sheet;
}

function str_(v) {
  if (v instanceof Date) return Utilities.formatDate(v, TZ, 'yyyy-MM-dd');
  return v == null ? '' : String(v);
}

function readAll_(name) {
  var sheet = sh_(name), h = SHEETS[name], n = sheet.getLastRow();
  if (n < 2) return [];
  var vals = sheet.getRange(2, 1, n - 1, h.length).getValues();
  return vals.filter(function (r) { return String(r[0]) !== ''; }).map(function (r) {
    var o = {};
    h.forEach(function (k, i) { o[k] = str_(r[i]); });
    return o;
  });
}

function writeAll_(name, objs) {
  var sheet = sh_(name), h = SHEETS[name], last = sheet.getLastRow();
  if (last > 1) sheet.getRange(2, 1, last - 1, h.length).clearContent();
  if (!objs.length) return;
  var rows = objs.map(function (o) { return h.map(function (k) { return o[k] == null ? '' : String(o[k]); }); });
  var need = rows.length + 1 - sheet.getMaxRows();
  if (need > 0) sheet.insertRowsAfter(sheet.getMaxRows(), need);
  sheet.getRange(2, 1, rows.length, h.length).setNumberFormat('@').setValues(rows);
}

function locked_(fn) {
  var lock = LockService.getScriptLock();
  lock.waitLock(25000);
  try {
    var out = fn();
    try { PropertiesService.getScriptProperties().setProperty('REV', String(Date.now())); } catch (e) {}
    return out;
  } finally { lock.releaseLock(); }
}

/* رقم تعديل البيانات: يتغير مع كل كتابة، فيعرف كل جهاز متى يُحدّث نفسه تلقائيًا */
function rev(token) {
  auth_(token);
  return PropertiesService.getScriptProperties().getProperty('REV') || '0';
}

function now_() { return Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd HH:mm:ss'); }
function today_() { return Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd'); }
function clip_(v, n) { return String(v == null ? '' : v).trim().slice(0, n); }
function num_(v, d) { var x = Number(v); return isFinite(x) ? x : (d || 0); }
function validDate_(d) { return /^\d{4}-\d{2}-\d{2}$/.test(String(d)); }

/* ===================== المستخدمون والجلسات ===================== */
function hash_(salt, pass) {
  var d = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, salt + ':' + pass, Utilities.Charset.UTF_8);
  return d.map(function (b) { return ('0' + (b & 255).toString(16)).slice(-2); }).join('');
}

function ensureAdmin_() {
  if (readAll_('Users').length) return;
  var salt = Utilities.getUuid();
  writeAll_('Users', [{
    username: 'admin', name: 'مدير النظام', salt: salt, hash: hash_(salt, 'admin123'),
    status: 'approved', role: 'admin', perms: '{}', lastLogin: '', lastActive: ''
  }]);
}

function parsePerms_(p) {
  if (p && typeof p === 'object') return p;   // كانت تُفرَّغ الصلاحيات عند تحليلها مرتين
  try { var o = JSON.parse(p || '{}'); return o && typeof o === 'object' ? o : {}; } catch (e) { return {}; }
}

function can_(u, perm) {
  if (u.role === 'admin') return true;
  if (perm === 'admin') return false;
  var list = Array.isArray(perm) ? perm : [perm];
  return list.some(function (p) { return u.perms && u.perms[p]; });
}

function revNow_() { return PropertiesService.getScriptProperties().getProperty('REV') || '0'; }
function userCached_(un) {
  var cache = CacheService.getScriptCache(), key = 'UR_' + revNow_() + '_' + un;
  try { var c = cache.get(key); if (c) return JSON.parse(c); } catch (e) {}
  var u = readAll_('Users').filter(function (x) { return x.username === un; })[0];
  if (u) { try { cache.put(key, JSON.stringify(u), 600); } catch (e) {} }
  return u;
}
function cacheBigPut_(key, str, ttl) {
  var CH = 30000, n = Math.ceil(str.length / CH);
  if (n > 28) return;
  var o = {};
  for (var i = 0; i < n; i++) o[key + '_' + i] = str.substr(i * CH, CH);
  o[key + '_N'] = String(n);
  try { CacheService.getScriptCache().putAll(o, ttl); } catch (e) {}
}
function cacheBigGet_(key) {
  var c = CacheService.getScriptCache(), n = Number(c.get(key + '_N') || 0);
  if (!n) return null;
  var ks = []; for (var i = 0; i < n; i++) ks.push(key + '_' + i);
  var m = c.getAll(ks), s = '';
  for (var j = 0; j < n; j++) { if (m[ks[j]] == null) return null; s += m[ks[j]]; }
  return s;
}
function auth_(token, perm) {
  if (!token) throw new Error('SESSION');
  var cache = CacheService.getScriptCache();
  var un = cache.get('S_' + token);
  if (!un) un = sessionRestore_(token);
  if (!un) throw new Error('SESSION');
  if (!cache.get('T_' + token)) {
    PropertiesService.getScriptProperties().setProperty('SS_' + token, un + '|' + Date.now());
    cache.put('T_' + token, '1', 120);
  }
  CUR_PLAT_ = cache.get('P_' + token) || '';
  var u = userCached_(un);
  if (!u || u.status !== 'approved') throw new Error('SESSION');
  u.perms = parsePerms_(u.perms);
  cache.put('S_' + token, un, SESSION_TTL);
  if (perm && !can_(u, perm)) throw new Error('غير مصرح لك بهذا الإجراء');
  return u;
}

/* الجلسات تُحفظ في خصائص السكريبت (دائمة) بجانب الكاش، فلا تنتهي بانتهاء الكاش ولا بإغلاق المتصفح */
function sessionSave_(token, username) {
  CacheService.getScriptCache().put('S_' + token, username, SESSION_TTL);
  PropertiesService.getScriptProperties().setProperty('SS_' + token, username + '|' + Date.now());
}
function sessionRestore_(token) {
  var props = PropertiesService.getScriptProperties();
  var v = props.getProperty('SS_' + token);
  if (!v) return '';
  var p = String(v).split('|'), un = p[0], seen = Number(p[1]) || 0;
  if (Date.now() - seen > SESSION_MAX_IDLE) { props.deleteProperty('SS_' + token); return ''; }
  props.setProperty('SS_' + token, un + '|' + Date.now());
  return un;
}
function sessionPrune_() {
  var props = PropertiesService.getScriptProperties(), all = props.getProperties();
  Object.keys(all).forEach(function (k) {
    if (k.indexOf('SS_') !== 0) return;
    var seen = Number(String(all[k]).split('|')[1]) || 0;
    if (Date.now() - seen > SESSION_MAX_IDLE) props.deleteProperty(k);
  });
}

function updateUser_(username, fields) {
  var sheet = sh_('Users'), h = SHEETS.Users, n = sheet.getLastRow();
  if (n < 2) return;
  var names = sheet.getRange(2, 1, n - 1, 1).getValues();
  for (var i = 0; i < names.length; i++) {
    if (String(names[i][0]) === username) {
      Object.keys(fields).forEach(function (k) {
        sheet.getRange(i + 2, h.indexOf(k) + 1).setValue(String(fields[k]));
      });
      return;
    }
  }
}

function publicUser_(u) {
  return { name: u.name, username: u.username, role: u.role, status: u.status, perms: parsePerms_(u.perms) };
}

function login(username, password, platform) {
  ensureAdmin_();
  username = clip_(username, 40).toLowerCase();
  var cache = CacheService.getScriptCache();
  var fkey = 'F_' + username;
  if (Number(cache.get(fkey) || 0) >= 5) throw new Error('تم تجاوز عدد المحاولات، حاول بعد 10 دقائق');
  var u = readAll_('Users').filter(function (x) { return x.username === username; })[0];
  if (!u || hash_(u.salt, String(password || '')) !== u.hash) {
    cache.put(fkey, String(Number(cache.get(fkey) || 0) + 1), 600);
    throw new Error('بيانات الدخول غير صحيحة');
  }
  if (u.status === 'pending') throw new Error('حسابك بانتظار موافقة الإدارة');
  if (u.status !== 'approved') throw new Error('تم إيقاف هذا الحساب');
  cache.remove(fkey);
  var token = Utilities.getUuid() + Utilities.getUuid();
  sessionSave_(token, username);
  sessionPrune_();
  var plat = normPlat_(platform);
  CUR_PLAT_ = plat;
  try { CacheService.getScriptCache().put('P_' + token, plat, SESSION_TTL); } catch (e) {}
  updateUser_(username, { lastLogin: now_(), lastActive: String(Date.now()), platform: plat, curPage: 'تسجيل الدخول', curPageAt: now_() });
  log_(u.name, 'دخول', 'النظام', username);
  return { token: token };
}

function logout(token) {
  try {
    var u = auth_(token);
    log_(u.name, 'خروج', 'النظام', u.username);
  } catch (e) { /* تجاهل */ }
  if (token) {
    CacheService.getScriptCache().remove('S_' + token);
    CacheService.getScriptCache().remove('T_' + token);
    PropertiesService.getScriptProperties().deleteProperty('SS_' + token);
  }
  return true;
}

function register(name, username, password) {
  name = clip_(name, 60);
  username = clip_(username, 30).toLowerCase();
  password = String(password || '');
  if (name.length < 2) throw new Error('اكتب الاسم بالكامل');
  if (!/^[a-z0-9_.]{3,30}$/.test(username)) throw new Error('اسم المستخدم: حروف إنجليزية صغيرة وأرقام فقط (3 أحرف على الأقل)');
  if (password.length < 6) throw new Error('كلمة المرور 6 أحرف على الأقل');
  return locked_(function () {
    ensureAdmin_();
    var users = readAll_('Users');
    if (users.some(function (u) { return u.username === username; })) throw new Error('اسم المستخدم مستخدم من قبل');
    if (users.filter(function (u) { return u.status === 'pending'; }).length >= 50) throw new Error('عدد الطلبات المعلقة كبير، تواصل مع الإدارة');
    var salt = Utilities.getUuid();
    users.push({ username: username, name: name, salt: salt, hash: hash_(salt, password), status: 'pending', role: 'user', perms: '{}', lastLogin: '', lastActive: '' });
    writeAll_('Users', users);
    log_(name, 'طلب تسجيل', 'النظام', username);
    return true;
  });
}

function changePassword(token, oldPass, newPass) {
  var u = auth_(token);
  newPass = String(newPass || '');
  if (newPass.length < 6) throw new Error('كلمة المرور الجديدة 6 أحرف على الأقل');
  if (hash_(u.salt, String(oldPass || '')) !== u.hash) throw new Error('كلمة المرور الحالية غير صحيحة');
  var salt = Utilities.getUuid();
  updateUser_(u.username, { salt: salt, hash: hash_(salt, newPass) });
  log_(u.name, 'تغيير كلمة المرور', 'النظام', u.username);
  return true;
}

function appUrl(token) {
  auth_(token);
  try { return ScriptApp.getService().getUrl(); } catch (e) { return ''; }
}

function ping(token) {
  var u = auth_(token);
  updateUser_(u.username, { lastActive: String(Date.now()) });
  return true;
}

/* الحضور الحي: منصة المستخدم (ويب/أندرويد) والشاشة المفتوحة الآن؛ opened=true يسجّل فتح الشاشة في السجل */
function presence(token, platform, page, opened) {
  var u = auth_(token);
  var plat = normPlat_(platform) || CUR_PLAT_;
  if (plat && plat !== CUR_PLAT_) { CUR_PLAT_ = plat; try { CacheService.getScriptCache().put('P_' + token, plat, SESSION_TTL); } catch (e) {} }
  var f = { lastActive: String(Date.now()), platform: plat };
  page = clip_(page, 60);
  if (page) { f.curPage = page; f.curPageAt = now_(); }
  updateUser_(u.username, f);
  if (opened && page) log_(u.name, 'فتح صفحة', page, '');
  return true;
}

/* ===================== السجل ===================== */
function log_(user, action, page, details) {
  var sheet = sh_('Log');
  sheet.appendRow([now_(), clip_(user, 60), clip_(action, 60), clip_(page, 60), clip_(details, 200), CUR_PLAT_]);
  if (sheet.getLastRow() > MAX_LOG_ROWS + 1) sheet.deleteRows(2, 1000);
}

function addLog(token, action, page, details) {
  var u = auth_(token);
  log_(u.name, action, page, details);
  return true;
}

/* ===================== تحميل البيانات ===================== */
function lastSetMap_() {
  var m = {};
  readAll_('Settlements').forEach(function (r) { if (r.to && (!m[r.wid] || r.to > m[r.wid])) m[r.wid] = r.to; });
  return m;
}

function workerOut_(w, full, ls) {
  var legacy = String(w.lastSet || ''), led = (ls && ls[w.id]) || '';
  return {
    id: w.id, name: w.name,
    card: full ? w.card : '', phone: full ? w.phone : '',
    loc: String(w.loc || ''), wage: num_(w.wage), hours: num_(w.hours, 8) || 8, lastSet: legacy > led ? legacy : led,
    hasCard: !!w.cardImg, hasPhoto: !!w.photo
  };
}

/* قيمة اليوم = الأجر + الساعات الإضافية × أجر الساعة */
function hourlyRate_(r, w) { return w ? ((num_(r.wage) || num_(w.wage)) / (num_(w.hours, 8) || 8)) : 0; }
/* أجر الحضور الأساسي: نصف يوم = نصف أجر اليوم، ساعات = عدد الساعات × أجر الساعة */
function recBase_(r, w) {
  if (r.status === HALF_STATUS) return num_(r.wage) / 2;
  if (r.status === HOURS_STATUS) return num_(r.xh) * hourlyRate_(r, w);
  return num_(r.wage);
}
/* الإضافي لا ينطبق على حضور الساعات (الخانة تحمل عدد الساعات نفسها) */
function recOt_(r, w) { return r.status === HOURS_STATUS ? 0 : num_(r.xh) * hourlyRate_(r, w); }
function recDays_(r, w) {
  if (r.status === HALF_STATUS) return 0.5;
  if (r.status === HOURS_STATUS) return Math.round(num_(r.xh) / ((w && num_(w.hours, 8)) || 8) * 100) / 100;
  return 1;
}
function recValue_(r, w) {
  return Math.round((recBase_(r, w) + recOt_(r, w)) * 100) / 100;
}

/* ترحيل لمرة واحدة: (1) الأيام المسوّاة حسب "آخر تسوية" القديم تُعلَّم مصروفة، (2) يُسجَّل المبلغ المصروف فعليًا لكل يوم مصروف */
function migrate_() {
  var props = PropertiesService.getScriptProperties();
  if (props.getProperty('MIG_PAIDAMT')) return;
  var workers = {}, ls = {};
  readAll_('Workers').forEach(function (w) { workers[w.id] = w; if (w.lastSet) ls[w.id] = w.lastSet; });
  var legacyDone = props.getProperty('MIG_SETTLE_ID');
  var att = readAll_('Attendance'), changed = false;
  att.forEach(function (r) {
    if (!legacyDone && !r.settleId && ls[r.wid] && r.date <= ls[r.wid] && r.status && r.status !== '--') { r.settleId = 'legacy'; changed = true; }
    if (r.settleId && r.paidAmt === '') { r.paidAmt = String(recValue_(r, workers[r.wid])); changed = true; }
  });
  if (changed) writeAll_('Attendance', att);
  props.setProperty('MIG_SETTLE_ID', '1');
  props.setProperty('MIG_PAIDAMT', '1');
}

function bootstrap(token) {
  var u = auth_(token);
  if (!PropertiesService.getScriptProperties().getProperty('MIG_PAIDAMT')) locked_(migrate_);
  if (Date.now() - num_(u.lastActive) > 60000) updateUser_(u.username, { lastActive: String(Date.now()) });
  var rv = revNow_();
  var ck = 'BS_' + rv + '_' + u.username;
  var hit = cacheBigGet_(ck);
  if (hit) { try { return JSON.parse(hit); } catch (e) {} }
  var full = can_(u, 'workers');
  var ls = lastSetMap_();
  var workers = readAll_('Workers').map(function (w) { return workerOut_(w, full, ls); });
  var att = readAll_('Attendance').map(function (r) {
    return { date: r.date, wid: r.wid, name: r.name, status: r.status, loc: r.loc, wage: num_(r.wage), xh: num_(r.xh), notes: r.notes, settleId: r.settleId, paidAmt: num_(r.paidAmt) };
  });
  var out = { user: publicUser_(u), workers: workers, att: att, locs: allLocs_(att), rev: rv };
  if (u.role === 'admin') out.users = readAll_('Users').map(publicUser_);
  cacheBigPut_(ck, JSON.stringify(out), 900);
  return out;
}

function allLocs_(att) {
  var seen = {}, list = [];
  readAll_('Locations').map(function (x) { return x.name; })
    .concat((att || []).map(function (r) { return r.loc; }))
    .forEach(function (l) { l = String(l || '').trim(); if (l && !seen[l]) { seen[l] = 1; list.push(l); } });
  return list;
}

/* ===================== الحضور والتسوية ===================== */
function saveDay(token, date, recs, partial) {
  var u = auth_(token, 'attendance');
  if (!validDate_(date)) throw new Error('تاريخ غير صحيح');
  if (!Array.isArray(recs)) throw new Error('بيانات غير صحيحة');
  return locked_(function () {
    var workers = {};
    readAll_('Workers').forEach(function (w) { workers[w.id] = w; });
    /* الأيام المسوّاة مغلقة: لا تُعدَّل ولا تُحذف، وتبقى كما سُجّلت وقت التسوية */
    var existing = readAll_('Attendance'), closed = {};
    existing.forEach(function (r) { if (r.date === date && r.settleId) closed[r.wid] = r; });
    var fresh = [], seen = {}, blocked = [], touched = {};
    recs.forEach(function (r) {
      var w = workers[String(r.wid)];
      if (!w || seen[w.id]) return;
      touched[w.id] = 1;
      if (STATUSES.indexOf(r.status) === -1 && clip_(r.loc, 80)) r.status = STATUSES[0]; /* كتابة مكان الحضور تحسب اليوم حتى لو الموقف -- */
      if (STATUSES.indexOf(r.status) === -1) return;
      seen[w.id] = 1;
      var extra = EXTRA_STATUSES.indexOf(r.status) !== -1 || r.status === HOURS_STATUS; /* خانة الساعات: إضافي أو عدد ساعات الحضور */
      var c = closed[w.id];
      if (c) {
        var same = c.status === r.status && String(c.loc) === clip_(r.loc, 80) &&
          num_(c.xh) === (extra ? Math.max(0, num_(r.xh)) : 0) && String(c.notes) === clip_(r.notes, 300) &&
          (!num_(r.wage) || num_(r.wage) === num_(c.wage));
        if (!same) blocked.push(w.name);
        return;
      }
      fresh.push({
        date: date, wid: w.id, name: w.name, status: r.status, loc: clip_(r.loc, 80),
        wage: num_(r.wage) > 0 ? num_(r.wage) : num_(w.wage), xh: extra ? Math.max(0, num_(r.xh)) : 0, notes: clip_(r.notes, 300),
        settleId: '', paidAmt: ''
      });
    });
    var all = existing.filter(function (r) { return r.date !== date || r.settleId || (partial && !touched[r.wid]); }).concat(fresh);
    writeAll_('Attendance', all);
    var known = readAll_('Locations').map(function (x) { return x.name; });
    var add = [];
    fresh.forEach(function (r) { if (r.loc && known.indexOf(r.loc) === -1 && add.indexOf(r.loc) === -1) add.push(r.loc); });
    if (add.length) writeAll_('Locations', known.concat(add).map(function (n) { return { name: n }; }));
    log_(u.name, 'حفظ يوم حضور', 'الحضور', date + ' (' + fresh.length + ')' + (blocked.length ? ' — محاولة تعديل أيام مغلقة: ' + blocked.join('، ') : ''));
    var att = all.filter(function (r) { return r.date === date; }).map(function (r) { return { date: r.date, wid: r.wid, name: r.name, status: r.status, loc: r.loc, wage: num_(r.wage), xh: num_(r.xh), notes: r.notes, settleId: r.settleId, paidAmt: num_(r.paidAmt) }; });
    return { att: att, locs: allLocs_(readAll_('Attendance')), locked: blocked };
  });
}

/* التسوية = صرف فعلي: لكل يوم يُسجَّل المبلغ المصروف (paidAmt).
 * - يوم جديد (له مكان حضور) ⇒ يُصرف كامل قيمته.
 * - يوم سبق صرفه ثم عُدِّل (ساعات إضافية، موقف، مكان...) ⇒ يُصرف الفرق فقط (قد يكون سالبًا = استرداد).
 * - يوم يُسجَّل لاحقًا داخل فترة سبقت تسويتها يبقى مستحقًا لأنه لم يُصرف فعلًا. */
function settleWorkers(token, ids, from, to, adj, loc, setDate) {
  var u = auth_(token, ['workers', 'attendance']);
  if (!validDate_(to)) throw new Error('تاريخ غير صحيح');
  if (from && !validDate_(from)) throw new Error('تاريخ غير صحيح');
  if (setDate && !validDate_(setDate)) throw new Error('يوم التسوية غير صحيح');
  if (setDate && String(setDate) > today_()) throw new Error('يوم التسوية لا يمكن أن يكون في المستقبل');
  from = from || '0000-00-00';
  adj = (adj && typeof adj === 'object') ? adj : {};
  if (!Array.isArray(ids) || !ids.length) throw new Error('حدد عاملًا واحدًا على الأقل');
  return locked_(function () {
    var workers = {};
    readAll_('Workers').forEach(function (w) { workers[w.id] = w; });
    var sid = 's' + Date.now() + Math.floor(Math.random() * 1000);
    var att = readAll_('Attendance'), per = {}, keys = [];
    att.forEach(function (r) {
      var w = workers[r.wid];
      if (!w || ids.indexOf(r.wid) === -1) return;
      if (r.date < from || r.date > to) return;
      if (loc && String(r.loc) !== String(loc)) return;
      var counts = String(r.loc).trim() !== '';
      if (!r.settleId && !counts) return;
      var val = counts ? recValue_(r, w) : 0;
      var diff = Math.round((val - (r.settleId ? num_(r.paidAmt) : 0)) * 100) / 100;
      if (Math.abs(diff) < 0.005) return;
      var wasPaid = !!r.settleId;
      var otPart = wasPaid ? diff : (counts ? recOt_(r, w) : 0);
      r.settleId = sid;
      r.paidAmt = String(val);
      var p = per[r.wid] || (per[r.wid] = { days: 0, amt: 0, ot: 0, name: w.name });
      if (!wasPaid) p.days = Math.round((p.days + recDays_(r, w)) * 100) / 100;
      p.amt += diff;
      p.ot += otPart;
      keys.push(r.date + '|' + r.wid);
    });
    var wids = Object.keys(per);
    if (!wids.length) throw new Error('لا توجد مبالغ مستحقة للصرف ضمن التحديد');
    writeAll_('Attendance', att);
    var sheet = sh_('Settlements'), total = 0, bTot = 0, dTot = 0, tTot = 0, t = now_(), d = setDate || today_();
    wids.forEach(function (id) {
      var p = per[id], a = Math.round(p.amt * 100) / 100, x = adj[id] || {};
      var b = Math.max(0, num_(x.b)), ded = Math.max(0, num_(x.d)), tx = Math.max(0, num_(x.t));
      var net = Math.round((a + b - ded - tx) * 100) / 100, ot = Math.round(p.ot * 100) / 100;
      total += a; bTot += b; dTot += ded; tTot += tx;
      sheet.appendRow([sid, d, from === '0000-00-00' ? '' : from, to, id, p.name, p.days, a, u.name, t, b, ded, tx, net, ot]);
    });
    total = Math.round(total * 100) / 100;
    log_(u.name, 'تسوية', 'التسوية', wids.length + ' عامل — ' + total + ' ج' + (bTot || dTot || tTot ? ' (مكافآت ' + bTot + ' / خصومات ' + dTot + ' / ضرائب ' + tTot + ')' : '') + ' حتى ' + to);
    return { sid: sid, count: wids.length, amount: total, to: to, date: d, wids: wids, keys: keys };
  });
}

/* ===================== المرتبات ===================== */
function listPayroll(token, from, to) {
  auth_(token, ['workers', 'attendance']);
  if (from && !validDate_(from)) throw new Error('تاريخ غير صحيح');
  if (to && !validDate_(to)) throw new Error('تاريخ غير صحيح');
  return readAll_('Settlements').filter(function (r) {
    return (!from || r.date >= from) && (!to || r.date <= to);
  }).map(function (r) {
    var a = num_(r.amount), b = num_(r.bonus), d = num_(r.ded), t = num_(r.tax);
    return {
      id: r.id, date: r.date, weekday: validDate_(r.date) ? weekday_(r.date) : '', from: r.from, to: r.to, wid: r.wid, name: r.name,
      days: num_(r.days), amount: a, ot: num_(r.ot), bonus: b, ded: d, tax: t,
      net: String(r.net) === '' ? Math.round((a + b - d - t) * 100) / 100 : num_(r.net), user: r.user
    };
  }).sort(function (x, y) { return x.date === y.date ? (x.id < y.id ? 1 : -1) : (x.date < y.date ? 1 : -1); });
}

/* تعديل المكافآت والخصومات والضرائب لسطر مرتب (تسوية + عامل) */
function updatePayrollAdj(token, id, wid, b, d, t) {
  var u = auth_(token, ['workers', 'attendance']);
  b = Math.max(0, num_(b)); d = Math.max(0, num_(d)); t = Math.max(0, num_(t));
  return locked_(function () {
    var sheet = sh_('Settlements'), h = SHEETS.Settlements, n = sheet.getLastRow();
    if (n < 2) throw new Error('السطر غير موجود');
    var vals = sheet.getRange(2, 1, n - 1, h.length).getValues();
    for (var i = 0; i < vals.length; i++) {
      if (String(vals[i][0]) === String(id) && String(vals[i][h.indexOf('wid')]) === String(wid)) {
        var a = num_(vals[i][h.indexOf('amount')]), net = Math.round((a + b - d - t) * 100) / 100;
        sheet.getRange(i + 2, h.indexOf('bonus') + 1, 1, 4).setValues([[String(b), String(d), String(t), String(net)]]);
        log_(u.name, 'تعديل مرتب', 'المرتبات', String(vals[i][h.indexOf('name')]) + ' — مكافآت ' + b + ' / خصومات ' + d + ' / ضرائب ' + t);
        return { id: id, wid: wid, bonus: b, ded: d, tax: t, net: net };
      }
    }
    throw new Error('السطر غير موجود');
  });
}

/* ===================== العاملون والصور ===================== */
function imgFolder_() {
  var it = DriveApp.getFoldersByName('إدارة الأمن - صور العاملين');
  return it.hasNext() ? it.next() : DriveApp.createFolder('إدارة الأمن - صور العاملين');
}

function saveImg_(dataUrl, label) {
  var m = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+\/=]+)$/.exec(String(dataUrl || ''));
  if (!m) throw new Error('صيغة الصورة غير مدعومة');
  if (m[2].length > 3000000) throw new Error('حجم الصورة كبير');
  var blob = Utilities.newBlob(Utilities.base64Decode(m[2]), m[1], label + '-' + Date.now());
  return imgFolder_().createFile(blob).getId();
}

function trashImg_(id) {
  if (!id) return;
  try { DriveApp.getFileById(id).setTrashed(true); } catch (e) { /* ملف محذوف */ }
}

function saveWorker(token, w) {
  var u = auth_(token, 'workers');
  var name = clip_(w && w.name, 80);
  if (!name) throw new Error('اكتب اسم العامل');
  return locked_(function () {
    var workers = readAll_('Workers');
    var cur = null;
    if (w.id) {
      cur = workers.filter(function (x) { return x.id === String(w.id); })[0];
      if (!cur) throw new Error('العامل غير موجود');
    } else {
      cur = { id: 'w' + Date.now() + Math.floor(Math.random() * 1000), lastSet: '', cardImg: '', photo: '' };
      workers.push(cur);
    }
    cur.name = name;
    cur.card = clip_(w.card, 30);
    cur.phone = clip_(w.phone, 20);
    cur.wage = Math.max(0, num_(w.wage));
    cur.hours = Math.max(1, num_(w.hours, 8)) || 8;
    cur.loc = clip_(w.loc, 60);
    if (w.cardImgData) { trashImg_(cur.cardImg); cur.cardImg = saveImg_(w.cardImgData, 'card'); }
    if (w.photoData) { trashImg_(cur.photo); cur.photo = saveImg_(w.photoData, 'photo'); }
    writeAll_('Workers', workers);
    log_(u.name, w.id ? 'تعديل عامل' : 'إضافة عامل', 'العاملين', name);
    return workerOut_(cur, true, lastSetMap_());
  });
}

function deleteWorkers(token, ids) {
  var u = auth_(token, 'workers');
  if (!Array.isArray(ids) || !ids.length) throw new Error('حدد عاملًا واحدًا على الأقل');
  return locked_(function () {
    var keep = [], n = 0;
    readAll_('Workers').forEach(function (w) {
      if (ids.indexOf(w.id) !== -1) { trashImg_(w.cardImg); trashImg_(w.photo); n++; } else keep.push(w);
    });
    writeAll_('Workers', keep);
    log_(u.name, 'حذف عاملين', 'العاملين', n + ' عامل');
    return { count: n };
  });
}

function getImage(token, id, kind) {
  auth_(token, ['workers', 'attendance']);
  var w = readAll_('Workers').filter(function (x) { return x.id === String(id); })[0];
  if (!w) return null;
  var fid = kind === 'card' ? w.cardImg : w.photo;
  if (!fid) return null;
  try {
    var blob = DriveApp.getFileById(fid).getBlob();
    return 'data:' + blob.getContentType() + ';base64,' + Utilities.base64Encode(blob.getBytes());
  } catch (e) { return null; }
}

/* ===================== إدارة المستخدمين والمتابعة ===================== */
function setUser(token, username, patch) {
  var me = auth_(token, 'admin');
  username = clip_(username, 40).toLowerCase();
  return locked_(function () {
    var users = readAll_('Users');
    var u = users.filter(function (x) { return x.username === username; })[0];
    if (!u) throw new Error('المستخدم غير موجود');
    if (u.role === 'admin') throw new Error('لا يمكن تعديل حساب المدير');
    if (patch && patch.status) {
      if (['approved', 'pending', 'suspended'].indexOf(patch.status) === -1) throw new Error('حالة غير صحيحة');
      u.status = patch.status;
      log_(me.name, 'تغيير حالة مستخدم', 'المستخدمين', u.name + ' → ' + patch.status);
    }
    if (patch && patch.perms) {
      var p = {};
      PERMS.forEach(function (k) { if (patch.perms[k]) p[k] = 1; });
      u.perms = JSON.stringify(p);
      log_(me.name, 'تعديل صلاحيات', 'المستخدمين', u.name);
    }
    writeAll_('Users', users);
    return users.map(publicUser_);
  });
}

function cleanPerms_(perms) {
  var p = {};
  PERMS.forEach(function (k) { if (perms && perms[k]) p[k] = 1; });
  return p;
}

function addUser(token, name, username, password, perms, isAdmin) {
  var me = auth_(token, 'admin');
  name = clip_(name, 60);
  username = clip_(username, 30).toLowerCase();
  password = String(password || '');
  if (name.length < 2) throw new Error('اكتب الاسم بالكامل');
  if (!/^[a-z0-9_.]{3,30}$/.test(username)) throw new Error('اسم المستخدم: حروف إنجليزية صغيرة وأرقام فقط (3 أحرف على الأقل)');
  if (password.length < 6) throw new Error('كلمة المرور 6 أحرف على الأقل');
  return locked_(function () {
    var users = readAll_('Users');
    if (users.some(function (u) { return u.username === username; })) throw new Error('اسم المستخدم مستخدم من قبل');
    var salt = Utilities.getUuid();
    users.push({
      username: username, name: name, salt: salt, hash: hash_(salt, password), status: 'approved',
      role: isAdmin ? 'admin' : 'user', perms: JSON.stringify(cleanPerms_(perms)), lastLogin: '', lastActive: ''
    });
    writeAll_('Users', users);
    log_(me.name, 'إضافة مستخدم', 'المستخدمين', name + ' (' + username + ')');
    return users.map(publicUser_);
  });
}

function resetUserPassword(token, username, newPass) {
  var me = auth_(token, 'admin');
  username = clip_(username, 40).toLowerCase();
  newPass = String(newPass || '');
  if (newPass.length < 6) throw new Error('كلمة المرور 6 أحرف على الأقل');
  var u = readAll_('Users').filter(function (x) { return x.username === username; })[0];
  if (!u) throw new Error('المستخدم غير موجود');
  if (u.role === 'admin') throw new Error('غيّر كلمة مرور المدير من زر 🔑 داخل حسابه');
  var salt = Utilities.getUuid();
  updateUser_(username, { salt: salt, hash: hash_(salt, newPass) });
  log_(me.name, 'إعادة تعيين كلمة مرور', 'المستخدمين', u.name);
  return true;
}

function deleteUser(token, username) {
  var me = auth_(token, 'admin');
  username = clip_(username, 40).toLowerCase();
  return locked_(function () {
    var users = readAll_('Users');
    var u = users.filter(function (x) { return x.username === username; })[0];
    if (!u) throw new Error('المستخدم غير موجود');
    if (u.role === 'admin') throw new Error('لا يمكن حذف حساب المدير');
    writeAll_('Users', users.filter(function (x) { return x.username !== username; }));
    log_(me.name, 'حذف مستخدم', 'المستخدمين', u.name);
    return readAll_('Users').map(publicUser_);
  });
}

function getMonitor(token) {
  auth_(token, 'admin');
  var log = readAll_('Log');
  var nowMs = Date.now();
  var users = readAll_('Users').map(function (u) {
    var mine = log.filter(function (l) { return l.user === u.name; });
    var last = mine.length ? mine[mine.length - 1].action : '';
    var act = Number(u.lastActive) || 0;
    var edits = mine.filter(function (l) { return l.action !== 'فتح صفحة' && l.action !== 'دخول' && l.action !== 'خروج'; });
    var lastEdit = edits.length ? edits[edits.length - 1] : null;
    return { name: u.name, username: u.username, lastLogin: u.lastLogin, online: !!(act && (nowMs - act) < ONLINE_MS), count: mine.length, lastAction: last,
      platform: u.platform || '', curPage: u.curPage || '', curPageAt: u.curPageAt || '', lastEdit: lastEdit ? (lastEdit.action + ' — ' + lastEdit.page + ' (' + lastEdit.time + ')') : '' };
  });
  return { users: users, log: log.slice(-600).reverse() };
}

/* ===================== دفتر دخول البوابة ===================== */
var AR_DAYS_ = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

function weekday_(d) {
  var p = d.split('-');
  return AR_DAYS_[new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2]), 12).getDay()];
}

function gateImgs_(g) {
  try { var a = JSON.parse(g.images || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; }
}

var GATE_PER_PAGE_ = 25;
function gateTypes_(g) {
  var n = gateImgs_(g).length, t = [];
  try { t = JSON.parse(g.imgTypes || '[]'); } catch (e) { t = []; }
  var out = []; for (var i = 0; i < n; i++) out.push(t[i] === 'pdf' ? 'pdf' : 'image');
  return out;
}
// رقم القيد (10 أرقام) = سنة(2) شهر(2) يوم(2) + الصفحة(2) + السطر(2)   مثال 2610100101 — يُحسب تلقائياً عند الحفظ
function p2_(n) { n = Math.floor(Number(n) || 0); return (n < 10 ? '0' : '') + n; }
function entryStr_(date, page, line) {
  var d = String(date || '').split('-');
  if (d.length !== 3) return '';
  return d[0].slice(-2) + d[1] + d[2] + p2_(page) + p2_(line);
}
function entryPos_(n) { return { page: Math.floor((n - 1) / GATE_PER_PAGE_) + 1, line: ((n - 1) % GATE_PER_PAGE_) + 1 }; }
// يُكمل الصفحة والسطر للسجلات التي لا تملكها (يومياً بترتيب م) ويرجع أكبر موضع مستخدم لكل يوم
function entryFill_(rows) {
  var by = {};
  rows.forEach(function (x) { (by[x.date] = by[x.date] || []).push(x); });
  Object.keys(by).forEach(function (d) {
    var g = by[d], mx = 0;
    g.forEach(function (x) { if (num_(x.page) > 0 && num_(x.line) > 0) mx = Math.max(mx, (num_(x.page) - 1) * GATE_PER_PAGE_ + num_(x.line)); });
    g.sort(function (a, b) { return num_(a.seq) - num_(b.seq); });
    g.forEach(function (x) {
      if (!(num_(x.page) > 0 && num_(x.line) > 0)) { var p = entryPos_(++mx); x.page = String(p.page); x.line = String(p.line); }
    });
  });
}
function entryNext_(rows, date, selfId) {
  var mx = 0;
  rows.forEach(function (x) { if (x.date === date && x.id !== selfId && num_(x.page) > 0 && num_(x.line) > 0) mx = Math.max(mx, (num_(x.page) - 1) * GATE_PER_PAGE_ + num_(x.line)); });
  return entryPos_(mx + 1);
}
function gateEntryNo_(g) { return entryStr_(g.date, g.page, g.line); }
function gateOut_(g) {
  var seq = num_(g.seq);
  return {
    id: g.id, seq: seq, weekday: g.weekday, date: g.date, plate: g.plate, time: g.time,
    action: g.action || '--', move: g.move || '', driver: g.driver, rep: g.rep || '', statement: g.statement, notes: g.notes,
    managers: g.managers, host: g.host,
    page: num_(g.page), line: num_(g.line),
    entryNo: gateEntryNo_(g),
    imgCount: gateImgs_(g).length, imgTypes: gateTypes_(g), createdBy: g.createdBy
  };
}

function saveGateFile_(dataUrl) {
  var m = /^data:(application\/pdf|image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+\/=]+)$/.exec(String(dataUrl || ''));
  if (!m) throw new Error('صيغة الملف غير مدعومة (صورة أو PDF)');
  if (m[2].length > 9000000) throw new Error('حجم الملف كبير (الحد 6 ميجا)');
  var isPdf = m[1] === 'application/pdf';
  var blob = Utilities.newBlob(Utilities.base64Decode(m[2]), m[1], 'gate-' + Date.now() + (isPdf ? '.pdf' : ''));
  return { id: imgFolder_().createFile(blob).getId(), type: isPdf ? 'pdf' : 'image' };
}

function listGate(token) {
  auth_(token, 'gate');
  var raw = readAll_('Gate'); entryFill_(raw);
  var rows = raw.map(gateOut_);
  rows.sort(function (a, b) { return a.date === b.date ? b.seq - a.seq : (a.date < b.date ? 1 : -1); });
  return rows.slice(0, 3000);
}

function saveGate(token, e) {
  var u = auth_(token, 'gate');
  e = e || {};
  var date = String(e.date || '');
  if (!validDate_(date)) throw new Error('حدد التاريخ');
  var time = clip_(e.time, 5);
  if (time && !/^\d{2}:\d{2}$/.test(time)) throw new Error('الوقت غير صحيح');
  var plate = clip_(e.plate, 40);
  var rep0 = clip_(e.rep, 80), driver0 = clip_(e.driver, 80);
  if (!plate && !driver0 && !rep0) throw new Error('اكتب رقم السيارة أو اسم السائق أو المندوب');
  var action = String(e.action || '--');
  if (['--', 'دخول', 'خروج'].indexOf(action) === -1) action = '--';
  var fresh = Array.isArray(e.newImages) ? e.newImages : [];
  if (fresh.length > 10) throw new Error('الحد الأقصى 10 صور في المرة الواحدة');
  return locked_(function () {
    var rows = readAll_('Gate'), cur = null;
    entryFill_(rows);
    if (e.id) {
      cur = rows.filter(function (x) { return x.id === String(e.id); })[0];
      if (!cur) throw new Error('السجل غير موجود');
      if (cur.date !== date) { var np0 = entryNext_(rows, date, cur.id); cur.page = String(np0.page); cur.line = String(np0.line); }
    } else {
      var mx = 0;
      rows.forEach(function (x) { mx = Math.max(mx, num_(x.seq)); });
      var np = entryNext_(rows, date, '');
      cur = { id: 'g' + Date.now() + Math.floor(Math.random() * 1000), seq: mx + 1, images: '[]', createdBy: u.name, createdAt: now_(), date: date, page: String(np.page), line: String(np.line) };
      rows.push(cur);
    }
    var imgs = gateImgs_(cur), types = gateTypes_(cur);
    var rm = (Array.isArray(e.removeIdx) ? e.removeIdx : []).map(Number);
    var keep = [], keepT = [];
    imgs.forEach(function (id, i) { if (rm.indexOf(i) === -1) { keep.push(id); keepT.push(types[i]); } });
    if (keep.length + fresh.length > 20) throw new Error('الحد الأقصى 20 ملفاً للتسجيل الواحد');
    imgs.forEach(function (id, i) { if (rm.indexOf(i) !== -1) trashImg_(id); });
    fresh.forEach(function (d) { var f = saveGateFile_(d); keep.push(f.id); keepT.push(f.type); });
    cur.imgTypes = JSON.stringify(keepT);
    cur.action = action; cur.rep = rep0;
    cur.date = date; cur.weekday = weekday_(date); cur.time = time; cur.plate = plate;
    cur.driver = driver0; cur.move = clip_(e.move, 40); cur.statement = clip_(e.statement, 600); cur.notes = clip_(e.notes, 300);
    cur.managers = clip_(e.managers, 200); cur.host = clip_(e.host, 80);
    cur.images = JSON.stringify(keep);
    writeAll_('Gate', rows);
    log_(u.name, e.id ? 'تعديل دخول بوابة' : 'تسجيل دخول بوابة', 'دفتر البوابة', (plate || driver0 || rep0) + ' — ' + date);
    return gateOut_(cur);
  });
}

function deleteGate(token, id) {
  var u = auth_(token, 'gate');
  return locked_(function () {
    var keep = [], hit = null;
    readAll_('Gate').forEach(function (g) { if (g.id === String(id)) hit = g; else keep.push(g); });
    if (!hit) throw new Error('السجل غير موجود');
    gateImgs_(hit).forEach(trashImg_);
    writeAll_('Gate', keep);
    log_(u.name, 'حذف دخول بوابة', 'دفتر البوابة', hit.plate + ' — ' + hit.date);
    return true;
  });
}

function getGateImage(token, id, idx) {
  auth_(token, 'gate');
  var g = readAll_('Gate').filter(function (x) { return x.id === String(id); })[0];
  if (!g) return null;
  var fid = gateImgs_(g)[Number(idx)];
  if (!fid) return null;
  try {
    var blob = DriveApp.getFileById(fid).getBlob();
    return 'data:' + blob.getContentType() + ';base64,' + Utilities.base64Encode(blob.getBytes());
  } catch (err) { return null; }
}

/* ===================== الإجراءات اليومية ===================== */
var P_TYPES_ = ['--', 'دخول', 'خروج'];
var P_SIGN_ = ['--', 'تم الختم والتوقيع'];

function fileList_(s) {
  try { var a = JSON.parse(s || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; }
}

function saveDoc_(dataUrl, label) {
  var m = /^data:(image\/(?:png|jpeg|webp)|application\/pdf);base64,([A-Za-z0-9+\/=]+)$/.exec(String(dataUrl || ''));
  if (!m) throw new Error('صيغة الملف غير مدعومة (صورة أو PDF)');
  if (m[2].length > 7000000) throw new Error('حجم الملف كبير');
  var blob = Utilities.newBlob(Utilities.base64Decode(m[2]), m[1], label + '-' + Date.now());
  return { id: imgFolder_().createFile(blob).getId(), t: m[1] === 'application/pdf' ? 'pdf' : 'img' };
}

function procOut_(p) {
  return {
    id: p.id, seq: num_(p.seq), date: p.date, weekday: p.weekday, plate: p.plate, driver: p.driver, rep: p.rep,
    statement: p.statement, ptype: p.ptype || '--', signed: p.signed || '--', signDate: p.signDate, signer: p.signer,
    bookPage: p.bookPage, supervisor: p.supervisor, notes: p.notes,
    docs: fileList_(p.docs).map(function (f) { return f.t; }), other: fileList_(p.other).map(function (f) { return f.t; }),
    createdBy: p.createdBy, page: num_(p.page), line: num_(p.line), entryNo: entryStr_(p.date, p.page, p.line)
  };
}

function listProcs(token) {
  auth_(token, 'procs');
  var raw = readAll_('Procs'); entryFill_(raw);
  var rows = raw.map(procOut_);
  rows.sort(function (a, b) { return a.date === b.date ? b.seq - a.seq : (a.date < b.date ? 1 : -1); });
  return rows.slice(0, 3000);
}

function saveProc(token, e) {
  var u = auth_(token, 'procs');
  e = e || {};
  var date = String(e.date || '');
  if (!validDate_(date)) throw new Error('حدد التاريخ');
  var plate = clip_(e.plate, 40), driver = clip_(e.driver, 80), rep = clip_(e.rep, 80);
  if (!plate && !driver && !rep) throw new Error('اكتب رقم السيارة أو اسم السائق أو المندوب / الموظف');
  var ptype = P_TYPES_.indexOf(e.ptype) === -1 ? '--' : e.ptype;
  var signed = P_SIGN_.indexOf(e.signed) === -1 ? '--' : e.signed;
  var signDate = clip_(e.signDate, 10);
  if (signed !== '--' && signDate && !validDate_(signDate)) throw new Error('تاريخ الختم والتوقيع غير صحيح');
  var nd = Array.isArray(e.newDocs) ? e.newDocs : [], no = Array.isArray(e.newOther) ? e.newOther : [];
  if (nd.length > 10 || no.length > 10) throw new Error('الحد الأقصى 10 ملفات في المرة الواحدة لكل بند');
  return locked_(function () {
    var rows = readAll_('Procs'), cur = null;
    entryFill_(rows);
    if (e.id) {
      cur = rows.filter(function (x) { return x.id === String(e.id); })[0];
      if (!cur) throw new Error('السجل غير موجود');
      if (cur.date !== date) { var np0 = entryNext_(rows, date, cur.id); cur.page = String(np0.page); cur.line = String(np0.line); }
    } else {
      var mx = 0;
      rows.forEach(function (x) { mx = Math.max(mx, num_(x.seq)); });
      var np = entryNext_(rows, date, '');
      cur = { id: 'p' + Date.now() + Math.floor(Math.random() * 1000), seq: mx + 1, docs: '[]', other: '[]', createdBy: u.name, createdAt: now_(), date: date, page: String(np.page), line: String(np.line) };
      rows.push(cur);
    }
    function apply(field, fresh, removeIdx) {
      var list = fileList_(cur[field]), rm = (Array.isArray(removeIdx) ? removeIdx : []).map(Number);
      var keep = list.filter(function (f, i) { return rm.indexOf(i) === -1; });
      if (keep.length + fresh.length > 30) throw new Error('الحد الأقصى 30 ملفًا لكل بند');
      list.forEach(function (f, i) { if (rm.indexOf(i) !== -1) trashImg_(f.id); });
      fresh.forEach(function (d) { keep.push(saveDoc_(d, 'proc')); });
      cur[field] = JSON.stringify(keep);
    }
    apply('docs', nd, e.removeDocs);
    apply('other', no, e.removeOther);
    cur.date = date; cur.weekday = weekday_(date); cur.plate = plate; cur.driver = driver; cur.rep = rep;
    cur.statement = clip_(e.statement, 300); cur.ptype = ptype; cur.signed = signed;
    cur.signDate = signed === '--' ? '' : signDate; cur.signer = signed === '--' ? '' : clip_(e.signer, 80);
    cur.bookPage = signed === '--' ? '' : clip_(e.bookPage, 40);
    cur.supervisor = clip_(e.supervisor, 80); cur.notes = clip_(e.notes, 300);
    writeAll_('Procs', rows);
    log_(u.name, e.id ? 'تعديل إجراء يومي' : 'إضافة إجراء يومي', 'الإجراءات اليومية', (plate || rep || driver) + ' — ' + date);
    return procOut_(cur);
  });
}

function deleteProc(token, id) {
  var u = auth_(token, 'procs');
  return locked_(function () {
    var keep = [], hit = null;
    readAll_('Procs').forEach(function (g) { if (g.id === String(id)) hit = g; else keep.push(g); });
    if (!hit) throw new Error('السجل غير موجود');
    fileList_(hit.docs).concat(fileList_(hit.other)).forEach(function (f) { trashImg_(f.id); });
    writeAll_('Procs', keep);
    log_(u.name, 'حذف إجراء يومي', 'الإجراءات اليومية', (hit.plate || hit.rep || hit.driver) + ' — ' + hit.date);
    return true;
  });
}

/* كل ملفات السجل دفعة واحدة (صور كاملة الوضوح + PDF) */
function getProcFiles(token, id) {
  auth_(token, 'procs');
  var p = readAll_('Procs').filter(function (x) { return x.id === String(id); })[0];
  if (!p) return { docs: [], other: [] };
  function load(list) {
    return list.map(function (f) {
      try {
        var blob = DriveApp.getFileById(f.id).getBlob();
        return { t: f.t, data: 'data:' + blob.getContentType() + ';base64,' + Utilities.base64Encode(blob.getBytes()) };
      } catch (err) { return { t: f.t, data: '' }; }
    });
  }
  return { docs: load(fileList_(p.docs)), other: load(fileList_(p.other)) };
}

function resetAll(token) {
  var u = auth_(token, 'admin');
  return locked_(function () {
    readAll_('Workers').forEach(function (w) { trashImg_(w.cardImg); trashImg_(w.photo); });
    writeAll_('Workers', []);
    writeAll_('Attendance', []);
    writeAll_('Locations', []);
    writeAll_('Settlements', []);
    log_(u.name, 'تصفير البرنامج', 'النظام', '');
    return true;
  });
}
