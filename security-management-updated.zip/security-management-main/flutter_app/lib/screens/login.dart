// شاشة الدخول + تسجيل مستخدم جديد
import 'package:flutter/material.dart';
import '../api.dart';
import '../state.dart';
import 'shell.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _u = TextEditingController();
  final _p = TextEditingController();
  final _rgName = TextEditingController();
  final _rgUser = TextEditingController();
  final _rgPass = TextEditingController();
  String _msg = '';
  bool _err = false;
  bool _busy = false;
  bool _reg = false;

  @override
  void initState() {
    super.initState();
    Api.getUrl();
  }

  void _say(String m, [bool e = false]) => setState(() { _msg = m; _err = e; });

  @override
  void dispose() {
    _u.dispose();
    _p.dispose();
    _rgName.dispose();
    _rgUser.dispose();
    _rgPass.dispose();
    super.dispose();
  }

  /// نافذة إعدادات الاتصال: تغيير رابط السيرفر + اختبار الاتصال قبل الحفظ
  Future<void> _serverDialog() async {
    final c = TextEditingController(text: (await Api.getUrl()) ?? '');
    String msg = '';
    bool err = false, busy = false;
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (dctx) => StatefulBuilder(builder: (ctx, setD) {
        Future<void> run(Future<void> Function() f) async {
          setD(() { busy = true; msg = ''; });
          try {
            await f();
          } on ApiException catch (e) {
            if (ctx.mounted) setD(() { msg = e.message; err = true; });
          } finally {
            if (ctx.mounted) setD(() => busy = false);
          }
        }
        return AlertDialog(
          title: const Text('إعدادات الاتصال بالويب', style: TextStyle(fontSize: 16)),
          content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Directionality(
              textDirection: TextDirection.ltr,
              child: TextField(
                controller: c,
                keyboardType: TextInputType.url,
                minLines: 1,
                maxLines: 4,
                style: const TextStyle(fontSize: 12),
                decoration: const InputDecoration(isDense: true, hintText: 'https://script.google.com/macros/s/.../exec'),
              ),
            ),
            if (busy) const Padding(padding: EdgeInsets.only(top: 12), child: Center(child: CircularProgressIndicator())),
            if (msg.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text(msg, style: TextStyle(color: err ? Colors.red.shade700 : Colors.green.shade700, fontWeight: FontWeight.w700, fontSize: 12.5)),
              ),
          ]),
          actions: [
            TextButton(onPressed: busy ? null : () => run(() async { await Api.resetUrl(); c.text = Api.defaultUrl; setD(() { msg = 'تمت العودة للسيرفر الافتراضي'; err = false; }); }), child: const Text('الافتراضي')),
            TextButton(onPressed: busy ? null : () => run(() async { final r = await Api.testUrl(c.text); setD(() { msg = r; err = false; }); }), child: const Text('اختبار')),
            FilledButton(
              onPressed: busy ? null : () => run(() async {
                await Api.testUrl(c.text);
                await Api.saveUrl(c.text);
                if (dctx.mounted) Navigator.pop(dctx);
              }),
              child: const Text('حفظ'),
            ),
          ],
        );
      }),
    );
  }

  Future<void> _login() async {
    setState(() => _busy = true);
    try {
      await Api.getUrl();
      final r = await Api.call('login', [_u.text.trim().toLowerCase(), _p.text, 'android']);
      await Api.saveToken((r as Map)['token'] as String);
      await App.I.bootstrap();
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const Shell()));
    } on SessionExpired {
      _say('انتهت الجلسة، حاول مرة أخرى', true);
    } on ApiException catch (e) {
      _say(e.message, true);
    } catch (e) {
      _say('خطأ غير متوقع: $e', true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _register() async {
    setState(() => _busy = true);
    try {
      await Api.getUrl();
      await Api.call('register', [_rgName.text.trim(), _rgUser.text.trim().toLowerCase(), _rgPass.text]);
      _say('تم إرسال الطلب — بانتظار موافقة الإدارة');
      setState(() => _reg = false);
    } on ApiException catch (e) {
      _say(e.message, true);
    } catch (e) {
      _say('خطأ غير متوقع: $e', true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 4),
                Center(
                  child: Container(
                    width: 60,
                    height: 60,
                    padding: const EdgeInsets.all(6),
                    decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                    child: Image.asset('assets/logo.png', fit: BoxFit.contain,
                        errorBuilder: (_, __, ___) => Icon(Icons.shield_outlined, size: 36, color: cs.primary)),
                  ),
                ),
                const SizedBox(height: 6),
                Text('إدارة الأمن', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: cs.onSurface)),
                const SizedBox(height: 18),
                Center(child: SizedBox(width: 240, child: Card(
                  elevation: 3,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        if (!_reg) ...[
                          TextField(
                            controller: _u,
                            textInputAction: TextInputAction.next,
                            decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8), labelStyle: TextStyle(fontSize: 12.5), labelText: 'اسم المستخدم', prefixIcon: Icon(Icons.person_outline), isDense: true),
                          ),
                          const SizedBox(height: 10),
                          TextField(
                            controller: _p,
                            obscureText: true,
                            onSubmitted: (_) => _login(),
                            decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8), labelStyle: TextStyle(fontSize: 12.5), labelText: 'كلمة المرور', prefixIcon: Icon(Icons.lock_outline), isDense: true),
                          ),
                        ] else ...[
                          TextField(controller: _rgName, decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8), labelStyle: TextStyle(fontSize: 12.5), labelText: 'الاسم بالكامل', isDense: true)),
                          const SizedBox(height: 10),
                          TextField(controller: _rgUser, decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8), labelStyle: TextStyle(fontSize: 12.5), labelText: 'اسم المستخدم', isDense: true)),
                          const SizedBox(height: 10),
                          TextField(controller: _rgPass, obscureText: true, decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8), labelStyle: TextStyle(fontSize: 12.5), labelText: 'كلمة المرور', isDense: true)),
                        ],
                        const SizedBox(height: 14),
                        if (_busy) const Center(child: CircularProgressIndicator())
                        else ...[
                          FilledButton(
                            onPressed: _reg ? _register : _login,
                            style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 8), textStyle: const TextStyle(fontSize: 13)),
                            child: Text(_reg ? 'إرسال طلب التسجيل' : 'دخول'),
                          ),
                          TextButton(
                            onPressed: () => setState(() { _reg = !_reg; _msg = ''; }),
                            child: Text(_reg ? 'لديك حساب؟ سجّل الدخول' : 'مستخدم جديد'),
                          ),
                        ],
                        TextButton.icon(
                          onPressed: _serverDialog,
                          icon: const Icon(Icons.cloud_outlined, size: 16),
                          label: const Text('إعدادات الاتصال بالويب', style: TextStyle(fontSize: 12)),
                        ),
                        if (_msg.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Text(_msg, textAlign: TextAlign.center, style: TextStyle(color: _err ? cs.error : Colors.green.shade700, fontSize: 13)),
                          ),
                      ],
                    ),
                  ),
                ))),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
