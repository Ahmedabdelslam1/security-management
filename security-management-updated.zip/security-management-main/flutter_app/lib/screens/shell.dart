// الهيكل الرئيسي: تنقل بأيقونات ملونة (هوية الويب) + ساعة حية + مزامنة تلقائية + تحديث تلقائي
import 'dart:async';
import 'package:flutter/material.dart';
import '../models.dart';
import '../state.dart';
import '../api.dart';
import '../updater.dart';
import '../widgets.dart';
import 'attendance.dart';
import 'workers.dart';
import 'settlement.dart';
import 'reports.dart';
import 'gate.dart';
import 'procs.dart';
import 'home.dart';
import 'users.dart';
import 'monitor.dart';
import '../main.dart' show Gate;
import 'settings.dart';

const _arDays = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
const _arMonths = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> with WidgetsBindingObserver {
  String _tab = 'home';
  String _presTab = '';
  int _presTick = 0;
  Timer? _sync;
  Timer? _updateCheck;
  DateTime _lastResume = DateTime.now();
  bool _active = true; // التطبيق في المقدمة؟ (نوقف المزامنة في الخلفية لتوفير البطارية والبيانات)

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    App.I.bootstrap(silent: true).catchError((_) {});
    Api.auth('srvVer').then((v) {
      App.I.srvVer = int.tryParse('$v') ?? 0;
      App.I.refresh();
      if (App.I.srvVer > 0 && App.I.srvVer < 4 && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          duration: Duration(seconds: 12),
          backgroundColor: Color(0xFFB45309),
          content: Text('سكربت Google قديم: حدّث Code.gs (الصق Loader.gs) — تم إخفاء موقفي نصف يوم/ساعات حتى لا تُلغى التسجيلات'),
        ));
      }
    }).catchError((_) {});
    // مزامنة فورية مع الويب: نسأل السيرفر عن رقم التعديل كل 15 ثانية، ونسحب البيانات فقط لو تغيّرت
    _sync = Timer.periodic(const Duration(seconds: 15), (_) {
      if (!_active) return;
      if (!App.I.loading) App.I.syncIfChanged().catchError((_) {});
      // نبضة حضور كل 3 دقائق (تبقي المستخدم "متصل" وتحدّث الشاشة الحالية)
      if (++_presTick % 12 == 0) App.I.presence(_presName(_tab));
    });
    // فحص التحديث بعد البدء بقليل، ثم كل 6 ساعات (autoUpdate نفسها تمنع التكرار)
    Future.delayed(const Duration(seconds: 6), () { if (mounted) autoUpdate(context); });
    _updateCheck = Timer.periodic(const Duration(hours: 6), (_) {
      if (mounted && _active) autoUpdate(context);
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    _active = s == AppLifecycleState.resumed;
    if (_active) {
      // عند الرجوع للتطبيق: مزامنة سريعة (فقط لو غاب أكثر من 5 ثوانٍ)
      if (DateTime.now().difference(_lastResume).inSeconds > 5) {
        App.I.syncIfChanged().catchError((_) {});
        App.I.presence(_presName(_tab));
      }
      autoUpdate(context);
    } else {
      _lastResume = DateTime.now();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _sync?.cancel();
    _updateCheck?.cancel();
    super.dispose();
  }

  DateTime _bootStart = DateTime.now();
  bool _retrying = false;

  Widget _bootView() {
    final err = App.I.bootError;
    final slow = DateTime.now().difference(_bootStart).inSeconds > 15;
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            if (err.isEmpty && !slow) const CircularProgressIndicator(),
            if (err.isEmpty && slow) ...[
              const CircularProgressIndicator(),
              const SizedBox(height: 14),
              const Text('التحميل بطيء... تأكد من الإنترنت ورابط السيرفر', textAlign: TextAlign.center),
            ],
            if (err.isNotEmpty) ...[
              const Icon(Icons.error_outline, color: Colors.red, size: 40),
              const SizedBox(height: 10),
              const Text('تعذّر تحميل البيانات', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              const SizedBox(height: 8),
              Directionality(
                textDirection: TextDirection.ltr,
                child: SelectableText(err, style: const TextStyle(color: Colors.red, fontSize: 12)),
              ),
            ],
            const SizedBox(height: 16),
            Wrap(spacing: 10, runSpacing: 8, alignment: WrapAlignment.center, children: [
              FilledButton(
                onPressed: _retrying ? null : () async {
                  setState(() { _retrying = true; _bootStart = DateTime.now(); });
                  try { await App.I.bootstrap(silent: true).timeout(const Duration(seconds: 60)); } catch (_) {}
                  if (mounted) setState(() => _retrying = false);
                },
                child: const Text('إعادة المحاولة'),
              ),
              OutlinedButton(
                onPressed: () async {
                  await App.I.logout();
                  if (mounted) Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => const Gate()), (_) => false);
                },
                child: const Text('تسجيل الخروج / تغيير السيرفر'),
              ),
            ]),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = App.I;
    final u = app.user;
    if (u == null) return _bootView();

    final tabs = <_Tab>[
      const _Tab('home', 'الرئيسية', Icons.home),
      if (u.can('attendance')) const _Tab('attendance', 'الحضور', Icons.checklist),
      if (u.can('attendance')) const _Tab('settlement', 'التسوية', Icons.payments_outlined),
      if (u.can('workers')) const _Tab('workers', 'العاملين', Icons.groups_outlined),
      if (u.can('reports')) const _Tab('reports', 'التقارير', Icons.bar_chart),
      if (u.can('gate')) const _Tab('gate', 'دفتر البوابة', Icons.door_front_door),
      if (u.isAdmin) const _Tab('users', 'المستخدمين', Icons.manage_accounts_outlined),
      if (u.isAdmin) const _Tab('monitor', 'المتابعة', Icons.monitor_heart_outlined),
      const _Tab('settings', 'الإعدادات', Icons.settings_outlined),
    ];
    if (!tabs.any((t) => t.id == _tab) && tabs.isNotEmpty) _tab = tabs.first.id;
    if (_presTab != _tab) {
      _presTab = _tab;
      App.I.presence(_presName(_tab), opened: true); // تسجيل فتح الشاشة وتحديث الشاشة الحالية
    }

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && _tab != 'home') setState(() => _tab = 'home');
      },
      child: Scaffold(
      appBar: AppBar(
        title: Text(appTitle(_tab)),
        centerTitle: true,
        actions: [
          // زر الرجوع للصفحة الرئيسية — ظاهر في كل الشاشات ما عدا الرئيسية نفسها
          if (_tab != 'home')
            IconButton(
              tooltip: 'الصفحة الرئيسية',
              onPressed: () => setState(() => _tab = 'home'),
              icon: const Icon(Icons.home_outlined, size: 21),
            ),
          // الساعة الحية: اليوم + التاريخ + الوقت — ودجت مستقلة تُعيد رسم نفسها فقط كل ثانية
          const Padding(
            padding: EdgeInsets.only(left: 10),
            child: _LiveClock(),
          ),
          // زر تحديث يدوي (مزامنة فورية)
          IconButton(
            tooltip: 'مزامنة الآن',
            onPressed: () async {
              final m = ScaffoldMessenger.of(context);
              m.showSnackBar(const SnackBar(content: Text('جاري البحث في GitHub Actions عن آخر إصدار وتحديث البيانات...'), duration: Duration(seconds: 2)));
              try { await Api.auth('refreshLive', []); } catch (_) {}
              try { await App.I.bootstrap(); } catch (_) {}
              final msg = await forceUpdate();
              m.showSnackBar(SnackBar(content: Text(msg)));
            },
            icon: const Icon(Icons.sync, size: 20),
          ),
        ],
      ),
      drawer: _drawer(context, u, tabs),
      body: Column(children: [
        ListenableBuilder(listenable: App.I, builder: (c, _) => _statusBar()),
        Expanded(child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 180),
        switchInCurve: Curves.easeOutCubic,
        switchOutCurve: Curves.easeIn,
        transitionBuilder: (child, anim) => FadeTransition(
          opacity: anim,
          child: SlideTransition(
            position: Tween<Offset>(begin: const Offset(0, 0.02), end: Offset.zero).animate(anim),
            child: child,
          ),
        ),
        // الاستماع لـ App يجعل كل شاشة تُعاد رسمها فور وصول بيانات جديدة من الويب
        child: ListenableBuilder(
          listenable: App.I,
          key: ValueKey(_tab),
          builder: (c, _) => _body(_tab),
        ),
      )),
      ]),
    ));
  }

  /// شريط حالة الاتصال: يظهر فقط عند انقطاع الاتصال أو عرض بيانات محفوظة لم تُحدَّث بعد
  Widget _statusBar() {
    final off = !App.I.online;
    if (!off && !App.I.fromCache) return const SizedBox.shrink();
    return Material(
      color: off ? const Color(0xFFB45309) : const Color(0xFF0369A1),
      child: InkWell(
        onTap: () => App.I.syncIfChanged().catchError((_) {}),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
          child: Row(children: [
            Icon(off ? Icons.cloud_off : Icons.sync, size: 15, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                off ? 'لا يوجد اتصال بالسيرفر — تُعرض آخر بيانات محفوظة (اضغط لإعادة المحاولة)' : 'جاري تحديث البيانات من الويب...',
                style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _drawer(BuildContext context, AppUser u, List<_Tab> tabs) {
    final items = <(String, String, IconData)>[
      ...tabs.map((t) => (t.id, t.label, t.icon)),
    ];
    return Drawer(
      child: Column(
        children: [
          UserAccountsDrawerHeader(
            decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF7C5CFC), Color(0xFFA78BFA)])),
            accountName: Text(u.name),
            accountEmail: Text(u.isAdmin ? 'مدير النظام' : 'مستخدم'),
            currentAccountPicture: CircleAvatar(
              backgroundColor: Colors.white,
              child: Image.asset('assets/icon_tile.png', fit: BoxFit.cover),
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 8),
              children: [
                for (var i = 0; i < items.length; i++)
                  SlideIn(
                    index: i,
                    child: _drawerTile(items[i].$1, items[i].$2, items[i].$3),
                  ),
                const Divider(height: 20),
                SlideIn(
                  index: items.length,
                  child: ListTile(
                    leading: const Icon(Icons.logout, color: Colors.red),
                    title: const Text('خروج', style: TextStyle(fontWeight: FontWeight.w800, color: Colors.red)),
                    onTap: () async {
                      Navigator.pop(context);
                      final ok = await showDialog<bool>(
                        context: context,
                        builder: (_) => AlertDialog(
                          title: const Text('تأكيد'),
                          content: const Text('هل تريد تسجيل الخروج؟'),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(_, false), child: const Text('إلغاء')),
                            FilledButton(onPressed: () => Navigator.pop(_, true), child: const Text('خروج')),
                          ],
                        ),
                      );
                      if (ok == true) {
                        await App.I.logout();
                        if (context.mounted) {
                          Navigator.of(context).pushNamedAndRemoveUntil('/', (_) => false);
                        }
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _drawerTile(String id, String label, IconData icon) {
    final cs = Theme.of(context).colorScheme;
    final sel = _tab == id;
    final colors = tabColors[id] ?? const [0xFFBAE6FD, 0xFF0369A1];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOutCubic,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          gradient: sel
              ? const LinearGradient(colors: [Color(0xFF7C5CFC), Color(0xFFA78BFA)])
              : null,
        ),
        child: ListTile(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          selected: sel,
          selectedColor: Colors.white,
          leading: IconTile(
            icon: icon,
            bg: Color(colors[0]),
            fg: Color(colors[1]),
            size: sel ? 36 : 32,
          ),
          title: Text(label,
              style: TextStyle(
                fontWeight: FontWeight.w800,
                color: sel ? Colors.white : Colors.black87,
              )),
          onTap: () {
            Navigator.pop(context);
            if (_tab != id) setState(() => _tab = id);
          },
        ),
      ),
    );
  }

  Widget _body(String tab) {
    switch (tab) {
      case 'home':
        return HomeScreen(onOpen: (id) => setState(() => _tab = id));
      case 'attendance':
        return AttendanceScreen(onHome: () => setState(() => _tab = 'home'));
      case 'workers':
        return const WorkersScreen();
      case 'settlement':
        return const SettlementScreen();
      case 'reports':
        return const ReportsScreen();
      case 'gate':
        return const GateScreen();
      case 'procs':
        return const ProcsScreen();
      case 'users':
        return const UsersScreen();
      case 'monitor':
        return const MonitorScreen();
      case 'settings':
        return const SettingsScreen();
      default:
        return Center(child: Text(appTitle(tab)));
    }
  }

  static String _presName(String tab) => tab == 'home' ? 'الرئيسية' : appTitle(tab);

  static String appTitle(String tab) {
    const m = {
      'home': 'إدارة الأمن',
      'attendance': 'الحضور',
      'settlement': 'التسوية',
      'workers': 'العاملين',
      'reports': 'التقارير',
      'gate': 'دفتر البوابة',
      'procs': 'الإجراءات اليومية',
      'users': 'المستخدمين',
      'monitor': 'المتابعة',
      'settings': 'الإعدادات',
    };
    return m[tab] ?? 'إدارة الأمن';
  }

  static String clockText(DateTime d) {
    int h = d.hour % 12; if (h == 0) h = 12;
    final ap = d.hour < 12 ? 'ص' : 'م';
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(h)}:${two(d.minute)}:${two(d.second)} $ap';
  }
}

class _Tab {
  final String id;
  final String label;
  final IconData icon;
  const _Tab(this.id, this.label, this.icon);
}


/// ساعة حية في شريط العنوان — تُعيد رسم نفسها فقط، فلا تُعاد رسم الشاشات تحتها كل ثانية
class _LiveClock extends StatefulWidget {
  const _LiveClock();
  @override
  State<_LiveClock> createState() => _LiveClockState();
}

class _LiveClockState extends State<_LiveClock> {
  Timer? _t;
  DateTime _now = DateTime.now();

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.18),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            '${_arDays[_now.weekday % 7]} ${_now.day} ${_arMonths[_now.month - 1]}',
            style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700),
          ),
          Text(
            _ShellState.clockText(_now),
            style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w900, height: 1.25),
          ),
        ],
      ),
    );
  }
}
