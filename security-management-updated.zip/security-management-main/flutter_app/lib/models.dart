// موديلات البيانات — مطابقة لمخرجات Code.gs
// دوال تحويل متسامحة: لا يتعطل التطبيق لو رجع السيرفر رقمًا بدل نص أو العكس
String _s(dynamic v, [String d = '']) => v == null ? d : '$v';
double _n(dynamic v, [double d = 0]) {
  if (v is num) return v.toDouble();
  return double.tryParse('${v ?? ''}'.trim()) ?? d;
}

class AppUser {
  final String name;
  final String username;
  final String role;
  final String status;
  final Map<String, dynamic> perms;
  AppUser({required this.name, required this.username, required this.role, required this.status, required this.perms});
  bool get isAdmin => role == 'admin';
  bool can(String p) => isAdmin || (perms[p] == 1 || perms[p] == true);
  factory AppUser.fromJson(Map j) => AppUser(
        name: _s(j['name']),
        username: _s(j['username']),
        role: _s(j['role']),
        status: _s(j['status']),
        perms: (j['perms'] as Map?)?.cast<String, dynamic>() ?? {},
      );
}

class Worker {
  final String id;
  final String name;
  final String card;
  final String phone;
  final double wage;
  final double hours;
  final String lastSet;
  final bool hasCard;
  final bool hasPhoto;
  final String loc; // مكان الحضور الثابت
  Worker({this.loc = '', required this.id, required this.name, required this.card, required this.phone, required this.wage, required this.hours, required this.lastSet, required this.hasCard, required this.hasPhoto});
  factory Worker.fromJson(Map j) => Worker(
        id: _s(j['id']),
        name: _s(j['name']),
        card: _s(j['card']),
        phone: _s(j['phone']),
        wage: _n(j['wage']),
        hours: _n(j['hours'], 8),
        lastSet: _s(j['lastSet']),
        hasCard: j['hasCard'] == true,
        hasPhoto: j['hasPhoto'] == true,
        loc: (j['loc'] ?? '').toString(),
      );
}

class AttRec {
  final String date;
  final String wid;
  final String name;
  String status;
  String loc;
  final double wage;
  double xh;
  String notes;
  final String settleId;
  final double paidAmt;
  AttRec({required this.date, required this.wid, required this.name, required this.status, required this.loc, required this.wage, required this.xh, required this.notes, this.settleId = '', this.paidAmt = 0});
  bool get counts => loc.trim().isNotEmpty;
  factory AttRec.fromJson(Map j) => AttRec(
        date: _s(j['date']),
        wid: _s(j['wid']),
        name: _s(j['name']),
        status: _s(j['status'], '--'),
        loc: _s(j['loc']),
        wage: _n(j['wage']),
        xh: _n(j['xh']),
        notes: _s(j['notes']),
        settleId: _s(j['settleId']),
        paidAmt: _n(j['paidAmt']),
      );
  Map<String, dynamic> toRec() => {'wid': wid, 'status': status, 'loc': loc, 'xh': xh, 'notes': notes};

  /// أجر الساعة لهذا السجل
  double hourlyOf(Worker w) => (wage > 0 ? wage : w.wage) / (w.hours <= 0 ? 8 : w.hours);
  /// ساعات الإضافي (حضور الساعات خانته هي ساعات الحضور نفسها وليست إضافي)
  double get otHours => status == kHoursStatus ? 0.0 : xh;
  /// الأجر الأساسي: نصف يوم = نصف أجر اليوم، ساعات = عدد الساعات × أجر الساعة
  double baseOf(Worker w) {
    if (status == kHalfStatus) return r2(wage / 2);
    if (status == kHoursStatus) return r2(xh * hourlyOf(w));
    return wage;
  }
  double otOf(Worker w) => otHours * hourlyOf(w);
  double valueOf(Worker w) => baseOf(w) + otOf(w);
  /// عدد الأيام: نصف يوم = 0.5، ساعات = ساعات ÷ ساعات اليوم
  double daysOf(Worker w) {
    if (status == kHalfStatus) return 0.5;
    if (status == kHoursStatus) return r2(xh / (w.hours <= 0 ? 8 : w.hours));
    return 1.0;
  }
}

class BootData {
  final AppUser user;
  final List<Worker> workers;
  final List<AttRec> att;
  final List<String> locs;
  final List<AppUser> users;
  BootData({required this.user, required this.workers, required this.att, required this.locs, required this.users});
  factory BootData.fromJson(Map j) => BootData(
        user: AppUser.fromJson(j['user'] as Map),
        workers: ((j['workers'] ?? []) as List).map((w) => Worker.fromJson(w as Map)).toList(),
        att: ((j['att'] ?? []) as List).map((r) => AttRec.fromJson(r as Map)).toList(),
        locs: ((j['locs'] ?? []) as List).map((l) => l.toString()).toList(),
        users: ((j['users'] ?? []) as List).map((u) => AppUser.fromJson(u as Map)).toList(),
      );
}

const String kHalfStatus = 'حضور نصف يوم';
const String kHoursStatus = 'حضور ساعات';
const List<String> kStatuses = ['--', 'حضور', kHalfStatus, kHoursStatus, 'حضور + وقت اضافى', 'حضور + مبيت'];
/// المواقف التي تفتح خانة الساعات (إضافي أو عدد ساعات)
bool usesXh(String s) => kExtraStatuses.contains(s) || s == kHoursStatus;
/// عدد أيام بدون كسر زائد (3 أو 0.5)
String dn(double d) => d == d.truncateToDouble() ? d.truncate().toString() : r2(d).toString();
const List<String> kExtraStatuses = ['حضور + وقت اضافى', 'حضور + مبيت'];

String fmtDate(String s) {
  if (s.isEmpty || s == '--') return '--';
  final p = s.split('-');
  if (p.length != 3) return s;
  return '${p[0]}/${p[1]}/${p[2]}';
}

double r2(double x) => (x * 100).round() / 100;

String otText(double h) {
  h = h.abs() < 0.005 ? 0 : h;
  if (h == 0) return '—';
  if (h == 1) return '1 ساعة';
  if (h == 2) return 'ساعتان';
  if (h >= 3 && h <= 10 && h % 1 == 0) return '${h.toInt()} ساعات';
  return '$h ساعة';
}

/// المستحق للعامل حتى اليوم: عدد الأيام + ساعات الإضافي = المبلغ
String workerDueText(Worker w, List<AttRec> att) {
  var days = 0.0;
  var hrs = 0.0;
  var amt = 0.0;
  final hpd = w.hours <= 0 ? 8.0 : w.hours;
  for (final r in att) {
    if (r.wid != w.id) continue;
    final h = (r.wage > 0 ? r.wage : w.wage) / hpd;
    final val = r.counts ? r.valueOf(w) : 0.0;
    final d = r2(val - (r.settleId.isNotEmpty ? r.paidAmt : 0));
    if (d > 0.005) {
      days += r.daysOf(w);
      amt += d;
      hrs += r.settleId.isNotEmpty ? (h > 0 ? d / h : 0.0) : r.otHours;
    }
  }
  return '${dn(r2(days))} يوم${hrs > 0 ? ' + ${otText(r2(hrs))} إضافي' : ''} = ${r2(amt)} ج';
}
