// بوابة الاتصال بالسيرفر — متوافقة مع Google Apps Script (doPost) و PHP (api.php)
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

/// خطأ شبكة (لا إنترنت / السيرفر لا يرد) — يختلف عن رفض السيرفر للطلب
class NetworkException extends ApiException {
  NetworkException([super.message = 'تعذر الوصول للسيرفر — تأكد من الرابط والإنترنت']);
}

class SessionExpired implements Exception {
  @override
  String toString() => 'انتهت الجلسة، سجّل الدخول من جديد';
}

Map _decodeJson(String s) => jsonDecode(s) as Map;

class Api {
  static final http.Client _shared = http.Client(); // اتصال دائم لتسريع كل الطلبات
  static String? _url;
  static String? _token;
  static const _kUrl = 'gas_url_v2';
  static const _kTok = 'gas_token';

  /// يُستدعى مرة واحدة عند انتهاء الجلسة (من أي شاشة) ليعيد التطبيق لشاشة الدخول
  static void Function()? onSessionExpired;
  static bool _expiredFired = false;

  // رابط السيرفر الافتراضي (Google Apps Script)
  static const String defaultUrl =
      'https://script.google.com/macros/s/AKfycbz5ISJT-vROTmczOi8HdFBvwSXiUZ3mMGzHJBfv732cumsONfMsu-yK_5-NuOzByHQu/exec';

  static Future<String?> getUrl() async {
    if (_url != null) return _url;
    final p = await SharedPreferences.getInstance();
    _url = p.getString(_kUrl);
    if (_url == null || _url!.trim().isEmpty) {
      _url = defaultUrl;
      await p.setString(_kUrl, defaultUrl);
    }
    return _url;
  }

  /// تنظيف الرابط وتحويله لشكله النهائي (يضيف api.php تلقائيًا لسيرفر PHP)
  static String normalize(String u) {
    u = u.trim();
    if (u.isEmpty) return defaultUrl;
    if (!u.startsWith('http://') && !u.startsWith('https://')) {
      throw ApiException('الرابط لازم يبدأ بـ https://');
    }
    return u;
  }

  static Future<void> saveUrl(String u) async {
    final n = normalize(u);
    _url = n;
    final p = await SharedPreferences.getInstance();
    await p.setString(_kUrl, n);
  }

  static Future<void> resetUrl() => saveUrl(defaultUrl);

  static Future<String?> getToken() async {
    if (_token != null) return _token;
    final p = await SharedPreferences.getInstance();
    _token = p.getString(_kTok);
    return _token;
  }

  static Future<void> saveToken(String t) async {
    _token = t;
    _expiredFired = false;
    final p = await SharedPreferences.getInstance();
    await p.setString(_kTok, t);
  }

  static Future<void> clear() async {
    _token = null;
    final p = await SharedPreferences.getInstance();
    await p.remove(_kTok);
  }

  /// هل الرابط يشير لسيرفر PHP؟
  static bool _isPhpBackend(String u) {
    final lower = u.toLowerCase();
    return lower.contains('api.php') ||
        lower.endsWith('/php') ||
        lower.contains('/php/') ||
        (!lower.contains('script.google.com') && !lower.contains('googleusercontent.com'));
  }

  /// هل السيرفر الحالي PHP؟ (لا يدعم الحفظ الجزئي لليوم)
  static Future<bool> isPhp() async {
    final u = (await getUrl()) ?? defaultUrl;
    return _isPhpBackend(u);
  }

  /// أوامر قراءة فقط: آمن إعادة محاولتها تلقائيًا عند فشل الشبكة
  static const _readOnly = {
    'bootstrap', 'rev', 'ping', 'srvVer', 'presence', 'listPayroll', 'getMonitor',
    'listGate', 'listProcs', 'getImage', 'getGateImage', 'getProcFiles', 'appUrl',
  };

  static String _endpoint(String u) {
    u = u.trim();
    // لو كان رابط مجلد PHP بدون api.php أضفه تلقائيًا
    if (!u.contains('script.google.com') &&
        !u.contains('googleusercontent.com') &&
        !u.endsWith('/exec') &&
        !u.endsWith('api.php') &&
        !u.contains('api.php?')) {
      if (u.endsWith('/')) return '${u}api.php';
      if (!u.contains('.php')) return '$u/api.php';
    }
    return u;
  }

  static Future<http.Response> _send(String u, String body, Duration timeout) async {
    final client = _shared;
    if (_isPhpBackend(u)) {
      // سيرفر PHP أو أي API مباشر — POST JSON عادي
      return client
          .post(Uri.parse(u), headers: {'Content-Type': 'application/json; charset=utf-8'}, body: body)
          .timeout(timeout);
    }
    // Google Apps Script: POST ثم اتبع تحويل 302 يدويًا
    final req = http.Request('POST', Uri.parse(u))
      ..headers['Content-Type'] = 'text/plain; charset=utf-8'
      ..body = body
      ..followRedirects = false;
    var res = await http.Response.fromStream(await client.send(req).timeout(timeout));
    var hops = 0;
    while ((res.statusCode == 301 || res.statusCode == 302 || res.statusCode == 303 || res.statusCode == 307) && hops < 5) {
      final loc = res.headers['location'];
      if (loc == null || loc.isEmpty) break;
      res = await client.get(Uri.parse(loc)).timeout(timeout);
      hops++;
    }
    return res;
  }

  // نداء عام: action = اسم الدالة، args = وسائطها (token أولًا حيث يلزم)
  static Future<dynamic> call(String action, [List args = const [], Duration? timeout]) async {
    var u = _url ?? await getUrl();
    if (u == null || u.trim().isEmpty) u = defaultUrl;
    u = _endpoint(u);

    final body = jsonEncode({'action': action, 'args': args});
    final attempts = _readOnly.contains(action) ? 2 : 1;
    // القراءة: 45ث (مع إعادة محاولة). الكتابة (قد تحمل صورًا): 90ث بلا إعادة تلقائية حتى لا تتكرر
    final to = timeout ?? Duration(seconds: attempts > 1 ? 45 : 90);

    http.Response? res;
    for (var i = 0; i < attempts; i++) {
      try {
        res = await _send(u, body, to);
        // أخطاء مؤقتة من الخادم (حمل زائد على جوجل) — أعد المحاولة لو القراءة فقط
        if (res.statusCode >= 500 && i + 1 < attempts) {
          await Future.delayed(const Duration(milliseconds: 600));
          continue;
        }
        break;
      } catch (_) {
        if (i + 1 >= attempts) throw NetworkException();
        await Future.delayed(const Duration(milliseconds: 600));
      }
    }
    if (res == null) throw NetworkException();

    Map out;
    try {
      final text = utf8.decode(res.bodyBytes, allowMalformed: true);
      // الردود الكبيرة (مثل bootstrap) تُفكّ في خيط منفصل حتى لا تتجمد الواجهة
      out = text.length > 60000 ? await compute(_decodeJson, text) : _decodeJson(text);
    } catch (_) {
      throw ApiException('رد غير صالح من السيرفر (${res.statusCode}) — تأكد من الرابط والنشر');
    }
    if (out['ok'] != true) {
      final msg = (out['error'] ?? 'خطأ غير معروف').toString();
      if (msg.contains('SESSION')) {
        await clear();
        if (!_expiredFired) {
          _expiredFired = true;
          onSessionExpired?.call();
        }
        throw SessionExpired();
      }
      throw ApiException(msg);
    }
    return out['data'];
  }

  // نداء موثّق: يضيف token تلقائيًا كأول وسيطة
  static Future<dynamic> auth(String action, [List args = const []]) async {
    final t = await getToken();
    return call(action, [if (t != null) t else '', ...args]);
  }

  /// اختبار اتصال برابط معيّن دون حفظه: يرجع نص النتيجة، ويرمي ApiException لو فشل
  static Future<String> testUrl(String candidate) async {
    final u = _endpoint(normalize(candidate));
    final sw = Stopwatch()..start();
    http.Response res;
    try {
      res = await _send(u, jsonEncode({'action': 'srvVer', 'args': ['']}), const Duration(seconds: 25));
    } catch (_) {
      throw NetworkException();
    }
    Map out;
    try {
      out = _decodeJson(utf8.decode(res.bodyBytes, allowMalformed: true));
    } catch (_) {
      throw ApiException('الرابط يرد لكن ليس سيرفر النظام (${res.statusCode}) — تأكد أنه رابط /exec المنشور');
    }
    // السيرفر السليم يرد "SESSION" لأنه لا توجد جلسة — وهذا دليل أنه يعمل
    final err = '${out['error'] ?? ''}';
    if (out['ok'] == true || err.contains('SESSION')) {
      return 'السيرفر يعمل ✓ (${sw.elapsedMilliseconds} مللي ثانية)';
    }
    throw ApiException('السيرفر رد بخطأ: $err');
  }
}
