// حالة التطبيق العامة — بيانات bootstrap + الجلسة + كاش محلي للتشغيل الفوري
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'api.dart';
import 'models.dart';

String _encodeJson(Object o) => jsonEncode(o);
Map _decodeMap(String s) => jsonDecode(s) as Map;

class App extends ChangeNotifier {
  static final App I = App._();
  App._();

  BootData? data;
  String attLoc = ''; // فلتر مكان الحضور عند الفتح من الرئيسية
  bool loading = false;

  String bootError = ''; // آخر خطأ في تحميل البيانات (للعرض بدل الدائرة الدائمة)
  int srvVer = 0; // إصدار سكربت Google (0 = غير معروف بعد، 4+ يدعم نصف يوم/ساعات)

  /// حالة الاتصال بالسيرفر (تتحدث مع كل طلب مزامنة)
  bool online = true;
  DateTime? lastSync; // آخر مرة وصلت فيها بيانات من الويب
  bool fromCache = false; // البيانات المعروضة من الكاش المحلي ولم تُحدَّث بعد

  AppUser? get user => data?.user;
  bool get ready => data != null;

  List<Worker> get workers => data?.workers ?? [];
  List<AttRec> get att => data?.att ?? [];
  List<String> get locs => data?.locs ?? [];
  /// كل أماكن الحضور: المسجلة سابقًا + الثابتة للعاملين
  List<String> get allLocs => <String>{...locs, ...workers.map((w) => w.loc).where((l) => l.isNotEmpty)}.toList();

  Worker worker(String id) => workers.firstWhere((w) => w.id == id, orElse: () => Worker(id: id, name: '؟', card: '', phone: '', wage: 0, hours: 8, lastSet: '', hasCard: false, hasPhoto: false));

  // ===== الكاش المحلي: يفتح التطبيق فورًا ببيانات آخر مزامنة ثم يحدّثها من الويب =====
  Future<File?> _cacheFile() async {
    try {
      final d = await getApplicationSupportDirectory();
      return File('${d.path}/boot_cache.json');
    } catch (_) {
      return null;
    }
  }

  /// يحمّل آخر بيانات محفوظة (لو وُجدت). يرجع true عند النجاح.
  Future<bool> loadCache() async {
    try {
      final f = await _cacheFile();
      if (f == null || !await f.exists()) return false;
      final txt = await f.readAsString();
      final j = txt.length > 60000 ? await compute(_decodeMap, txt) : _decodeMap(txt);
      data = BootData.fromJson(j);
      fromCache = true;
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> _saveCache(Object raw) async {
    try {
      final f = await _cacheFile();
      if (f == null) return;
      final s = await compute(_encodeJson, raw);
      await f.writeAsString(s, flush: true);
    } catch (_) {}
  }

  Future<void> _clearCache() async {
    try {
      final f = await _cacheFile();
      if (f != null && await f.exists()) await f.delete();
    } catch (_) {}
  }

  Future<void>? _bootFut;

  /// تحميل كامل للبيانات. الطلبات المتزامنة تشترك في نفس الطلب (لا تكرار).
  Future<void> bootstrap({bool silent = false}) {
    final running = _bootFut;
    if (running != null) return running;
    final f = _doBootstrap(silent);
    _bootFut = f;
    unawaited(f.whenComplete(() => _bootFut = null).catchError((_) {}));
    return f;
  }

  Future<void> _doBootstrap(bool silent) async {
    if (!silent) _setLoading(true);
    try {
      final j = await Api.auth('bootstrap');
      final bd = BootData.fromJson(j as Map);
      data = bd;
      final r = j['rev'];
      _rev = r == null ? null : '$r'; // رقم التعديل يأتي مع البيانات (سكربت محدّث) لتجنب سحب مكرر
      bootError = '';
      online = true;
      fromCache = false;
      lastSync = DateTime.now();
      notifyListeners();
      unawaited(_saveCache(j));
    } on NetworkException catch (e) {
      online = false;
      bootError = '$e';
      notifyListeners();
      rethrow;
    } catch (e) {
      bootError = '$e';
      rethrow;
    } finally {
      if (!silent) _setLoading(false);
    }
  }

  String? _rev;
  bool _syncing = false;

  /// مزامنة خفيفة: تسأل السيرفر عن رقم التعديل فقط، وتسحب البيانات كاملة إذا تغيّر
  Future<void> syncIfChanged() async {
    if (_syncing || _bootFut != null) return;
    _syncing = true;
    try {
      final v = (await Api.auth('rev')).toString();
      final wasOffline = !online;
      online = true;
      if (wasOffline) notifyListeners();
      if (_rev == v && !fromCache) return;
      await bootstrap(silent: true);
      _rev ??= v;
    } on NetworkException {
      if (online) {
        online = false;
        notifyListeners();
      }
    } finally {
      _syncing = false;
    }
  }

  /// الحضور الحي للمتابعة: المنصة (أندرويد) والشاشة المفتوحة الآن؛ opened=true يسجّل فتح الشاشة
  Future<void> presence(String page, {bool opened = false}) async {
    try { await Api.auth('presence', ['android', page, opened]); } catch (_) {}
  }

  /// مسح الحالة المحلية دون الاتصال بالسيرفر (عند انتهاء الجلسة)
  Future<void> reset() async {
    data = null;
    _rev = null;
    bootError = '';
    fromCache = false;
    await _clearCache();
    notifyListeners();
  }

  Future<void> logout() async {
    try { await Api.auth('logout').timeout(const Duration(seconds: 5)); } catch (_) {}
    await Api.clear();
    await reset();
  }

  void _setLoading(bool v) {
    loading = v;
    notifyListeners();
  }

  // تحديث قائمة المستخدمين بعد أي تعديل إداري (السيرفر يرجع القائمة الجديدة)
  void updateUsers(List<AppUser> us) {
    if (data != null) {
      data = BootData(user: data!.user, workers: data!.workers, att: data!.att, locs: data!.locs, users: us);
      notifyListeners();
    }
  }

  /// لإعادة رسم الشاشات بعد تعديلات محلية على البيانات
  void refresh() => notifyListeners();
  void toast() => notifyListeners();
}
